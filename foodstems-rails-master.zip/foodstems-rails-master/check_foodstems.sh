#!/bin/bash
 status="$(curl -Is https://foodstems.com/app | head -1)"
  validate=( $status )
  if [ ${validate[-2]} == "200" ]; then
      echo OK
  else
      echo NOT RESPONDING
      echo STARTING
      cd /var/www/foodstems/
      rails s puma -e production
  fi
