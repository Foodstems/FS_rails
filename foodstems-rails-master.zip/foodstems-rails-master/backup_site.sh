#!/bin/bash
now=$(date +"%d_%m_%Y")

awk '{print "pg_dump --dbname=postgresql://" $1 ":" $2 "@localhost:5432/foodstem_production > /tmp/db.sql"}' /home/ubuntu/.dbpassword | /bin/bash

zip /tmp/db.zip /tmp/db.sql
zip -r /tmp/images.zip /var/www/foodstems/public/uploads/*

aws s3 cp /tmp/db.zip "s3://foodstems-backup/db_$now.zip"
aws s3 cp /tmp/images.zip "s3://foodstems-backup/images_$now.zip"
