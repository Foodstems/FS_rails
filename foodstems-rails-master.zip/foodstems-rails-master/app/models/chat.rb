class Chat < ActiveRecord::Base
 sync :all
end
