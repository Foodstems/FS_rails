class MyChat < ActiveRecord::Base
end
