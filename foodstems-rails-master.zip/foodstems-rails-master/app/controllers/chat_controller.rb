class ChatController < ApplicationController
	 skip_before_filter :verify_authenticity_token  
	 #layout "fa_layout"
	def index
		@chats = Chat.all
		@chat = Chat.new		
		#render :json => @chats
	end

	def new
		 @article = Chat.new
	end

	def create
		#abort spree_current_user.user_profile.to_json.inspect
		@chat = Chat.new(message: params[:chat][:message])
		@chat.save
		sync_new @chat
		data = [
			"status": "success", 
			"message":"Message created"
		]
		render :json => data
		#respond_with { @chat }
	end


	def destroy
		
		@chat = Chat.find(params[:id])
		@chat.destroy
		sync_destroy  @chat
		data = [
			"status": "success", 
			"message":"Message removed"
		]
		render :json => data
	end
end
