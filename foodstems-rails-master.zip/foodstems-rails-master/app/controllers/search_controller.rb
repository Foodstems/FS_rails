	class SearchController < Spree::StoreController
		#todo : get relevant products and profiles
		#first get profiles and products that are in user's community
		def index
                        @profile_lat = spree_current_user.lat.nil? ? 0 : spree_current_user.lat
                        @profile_lng = spree_current_user.lng.nil? ? 0 : spree_current_user.lng

                        @product = Spree::Product.all
                                .where(" name ilike '"+params[:name]+"%' OR name ilike '% "+params[:name]+"%'")
                                .order(" 3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) ASC ")
                                .page(nil).per(Rails.application.config.catalogue_products_per_page)
                        @profile = Spree::UserProfile.all.where(" first_name ilike '"+params[:name]+"%' OR first_name ilike '% "+params[:name]+"%' OR last_name ilike '"+params[:name]+"%' OR last_name ilike '% "+params[:name]+"%'").page(nil).per(Rails.application.config.catalogue_products_per_page)
                end

		def search_product_in_chat
			@product = Spree::Product.all.where(" name ilike '%"+params[:name]+"%' ").page(nil).per(Rails.application.config.catalogue_products_per_page)
		end

		def search_product_in_post
			@product = Spree::Product.all.where(" name ilike '%"+params[:name]+"%' ").page(nil).per(Rails.application.config.catalogue_products_per_page)
		end

		#right side search
		def search
			# 3959 * acos( cos( radians(37) ) * cos( radians( lat ) ) * cos( radians( lng ) - radians(-122) ) + sin( radians(37) ) * sin( radians( lat ) ) ) 
			@taxons = Spree::Taxon.all
			#@products = Spree::Product.all.page(nil).per(Rails.application.config.catalogue_products_per_page)
			@products = Spree::Product.all
			@min_price = Spree::Price.order(amount: :asc).first.nil? ? 0.1 :  Spree::Price.order(amount: :asc).first.amount
			@max_price = Spree::Price.order(amount: :desc).first.nil? ? 0.1 :  Spree::Price.order(amount: :desc).first.amount

			#abort spree_current_user.inspect
			@category 		= params[:category]
			#@price_from 	= params[:price_from].nil? ? @min_price.to_f : params[:price_from] 
			#@price_to 		= params[:price_to].nil? ? @max_price.to_f : params[:price_to] 
			@distance_to	= params[:distance_to].nil? ? 10 : params[:distance_to] 
			@profile_lat = spree_current_user.lat.nil? ? 0 : spree_current_user.lat
			@profile_lng = spree_current_user.lng.nil? ? 0 : spree_current_user.lng 
			#get max distance 
			@c = @products.select("3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) as distance")
			@c.select("id, 3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) as distance").order("3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) ASC")
			
			@max_distance = @c.map{|x| x.distance}.max.to_i + 1

			#abort @max_distance.inspect
			@products = @products
				.select("max(spree_products.id), max(ssi.count_on_hand), 3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) as distance")
			@products = @products.group("spree_products.id, ssi.count_on_hand")
			#http://stackoverflow.com/a/2102391/391770
			@products = @products
				.having("3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) < ?", @distance_to.to_f)
     			
			@products = @products.order("ssi.count_on_hand<1, 3959 * acos( cos( radians(#{@profile_lat}) ) * cos( radians(lat) ) * cos( radians(lng) - radians(#{@profile_lng}) ) + sin( radians(#{@profile_lat}) ) * sin( radians(lat))) ASC")
			#@products = @products.price_between(@price_from, @price_to)
			#@products = @products.joins('INNER JOIN spree_variants sv ON spree_products.id = sv.product_id')
			@products = @products.joins('INNER JOIN spree_variants sv ON sv.product_id = spree_products.id  INNER JOIN spree_stock_items ssi ON sv.id=ssi.variant_id')

			if !@category.nil? && @category.to_i > 0
		    	@products = @products.joins('INNER JOIN spree_products_taxons spt ON spree_products.id=spt.product_id')
		    	@products = @products.where('spt.taxon_id = ?', @category.to_i)
		    end	

		    @_products = @products.select("spree_products.id")

			if params[:products_display].present?
				per_page = 8
				@products = @products.select("spree_products.*").page(params[:page]).per(per_page).all
				#abort @products.inspect
				@pages = (@_products.length.to_i / per_page).ceil
				@page = params[:page].to_i + 1
				render :search_products
			end

			@products = Spree::Product.where(id: @_products.map{|x| x.id}).page(nil).per(1000)		
		end
	end	

