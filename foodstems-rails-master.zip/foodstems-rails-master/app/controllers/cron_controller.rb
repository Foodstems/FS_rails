class CronController < ApplicationController
  helper Spree::Helpers::LinkToCol
  helper Spree::Helpers::RatingHelper
  helper Spree::Helpers::StringHelper
  helper Spree::Helpers::MyErrorHelper
  helper Spree::Helpers::NotifyHelper
  helper_method :my_path_div

  include Spree::Helpers::NotifyHelper
  include PublicActivity::StoreController

  def ship_local_orders

    orders = Spree::Order.where("shipment_state = ?", "pending")
    orders.each do |order|
        if order.shipments.first.shipping_method.name == 'Local Pickup' ||
        	order.shipments.first.shipping_method.name == 'Drop Off'

       		shipment  = Spree::Shipment.where("order_id = ? ", order.id).first
    		shipment.tracking               = nil
	        shipment.shipped_at             = DateTime.now.to_date
	        shipment.tracking_url_provider  = nil
	        shipment.label_url              = nil
	        shipment.shippo_object_id       = nil
	        shipment.state                  = 'shipped'
	        shipment.save

            order.shipment_state = 'shipped'
            order.save

        end 
    end

    render json: {"status"=>"done"}
    
  end


  #Check for transaction status after 3 days from 2nd payment
  #If status is settled then update seller's balance for that transactions' amount
  #only these transaction would be available for withdraw
  #
  def transaction_status
  	# payments that funds should be released to sellers
  	puts "Execution started at : #{Time.zone.now}" 
  	payments = Spree::Payment.where("is_settled = 0 AND is_disputed = 0 and is_refunded = 0")

  	payments.each do |payment|
  		next if payment.response_code.nil?

  		transaction = Braintree::Transaction.find(payment.response_code)
  		
  		if transaction.escrow_status == "held"
			#release funds after 3 days only if escrow status is held		
  			if TimeDifference.between(Time.zone.now, payment.updated_at).in_days > 3
  				payment.is_settled = 1
  			end

  		else 
  			#if there are unsettled transaction for any reason save in db for further investigation
  			failed = Spree::Foodstem::FailedTransaction.new
  			failed.response_code 	= payment.response_code
  			failed.status 			= transaction.status
  			failed.payment_id		= payment.id
  			failed.save 
  		end
  	end
  	puts "Execution ended at : #{Time.zone.now}"
  	abort
  end


	def finished_order_notifications
		orders = Spree::Order.where("confirmed > 0").order(id: :desc)

		orders.each do |order|
		
			user = order.user
			feedback = Spree::Foodstem::Feedback.where("order_id = ? AND user_id = ?", order.id, user.id)

			if feedback.size.to_i < 1
				my_notify user, order, false, option1: 100, option2: order.id 
			end

		end

		render json: {"status"=>"done"}
	end

	def check_auction_status
		auctions = Spree::Foodstem::Auction.all
		
		auctions.each do |a|
			
			if DateTime.now.to_time > a.auction_ends 
				a.status = 1
				a.save

			end
			if a.status == 1
				#abort a.product.id.inspect
				#set stock to 0
				#auction.product.count_on_hand = 0
				p = Spree::Product.find(a.product.id)
				p.set_stock_count(0)
				p.save
			end
		end

		render json: {"status"=>"done"}
	end

	def check_15_days_after_shipping

		orders = Spree::Order.where("confirmed = 0")

		orders.each do |order|
			
			if order.shipments.any? && order.shipments.first.state == 'shipped' 
				if (Time.zone.now.to_date - order.shipments.first.created_at.to_date).to_i > 15 
					order.confirmed = 1
					order.save
				end
				#abort order.shipments.first.inspect
			end
		end
		render json: {"status"=>"done"}
	end



end