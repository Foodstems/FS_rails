PublicActivity.config.table_name = 'foodstem_activities'
