Devise.secret_key = '1baa75e5fd5c2dc05e9afde4f941cf08507b2a79ab8ad5ecb0d5689bb772fc9ba4b22f3769f68b4b7949639a969075b4b71c'

Devise.setup do |config|
  config.reconfirmable = true
  config.mailer = 'Spree::Foodstem::UserMailer'
  require "omniauth-facebook"
  config.omniauth :facebook, 
  	'135722800257500', 
  	'f8cdc37f868dbda6a1c59e4c5d025913', 
    scope: 'public_profile,email,user_friends,user_birthday', 
    info_fields: 'id,name,email,first_name,last_name,birthday',   
  	secure_image_url: false,  
  	image_size: { width: 500, height: 500 },
    token_params: { parse: :json }
end