# Braintree::Configuration.logger       = Logger.new('log/braintree.log')
# payment_method = Spree::PaymentMethod.available.find { |x| x[:name] == 'Default' }.preferences
# Braintree::Configuration.environment  = payment_method[:environment].to_sym # ENV['BRAINTREE_ENV']         || :sandbox
# Braintree::Configuration.merchant_id  = payment_method[:merchant_id] # ENV['BRAINTREE_MERCHANT_ID'] || '964py6m66y5mbx9n'
# Braintree::Configuration.public_key   = payment_method[:public_key] # ENV['BRAINTREE_PUBLIC_KEY']  || '8b28qgfvm2ks6nkt'
# Braintree::Configuration.private_key  = payment_method[:private_key] # ENV['BRAINTREE_PRIVATE_KEY'] || '268c11fa064bee60b5a2b26cef554f5f'
# #Rails.application.config.master_merchant_account_id = payment_method[:merchant_account_id]
# Rails.application.configure do
#   config.master_merchant_account_id = payment_method[:merchant_account_id]
# end

Braintree::Configuration.environment = :sandbox
Braintree::Configuration.logger = Logger.new('log/braintree.log')
Braintree::Configuration.merchant_id = 'xfj5qkg6bfz4ykpp'
Braintree::Configuration.public_key = '5bg7hw5y2rwhfgqw'
Braintree::Configuration.private_key = '69a6b9bfa68e86c1575c803dc06dc152'

