require 'link_to_col'

map = {
  # Product's paths
  new_product_path: 1,
  products_path: 2,
  edit_product_path: 1,
  create_product_path: 1,
  foodstem_order_path: 1,
  destroy_product_path: 2,
  DELETE4PROD_destroy_product_path: 1,
  product_path: 1,
  catalogue_products_path: 2,
  search_products_path: 2,
  foodstem_orders_path: 2,
  foodstem_incoming_orders_path: 2,
  outgoing_orders_path: 2,
  incoming_orders_path: 2,
  order_path: 1,
  orders_path: 1,
  feedbacks_path: 2,

  #Profile's paths
  profile_path: 0,
  edit_profile_path: 0,
  merchant_path: 1,
  edit_avatar_thumbnail_profile_path: 1,

  #Vendor's paths
  favorite_vendors_path: 2,
  DELETE_favorite_vendor_path: 0,
  POST_favorite_vendors_path: 0,

  #Conversation's paths
  conversation_send_message_path: 2,
  conversations_path: 2,
  conversation_path: 1,
  new_conversation_path: 1,
  edit_conversation_path: 1,
  #conversation_conference_path: 1,

  #Ticket's path
  POST_tickets_path: 1,
  tickets_path: 2,
  ticket_path: 1,
  new_ticket_path: 1,
  PATCH_tickets_path: 1,

  #Post's paths
  foodstem_post_path: 1,
  foodstem_posts_path: 2,
  POST_foodstem_posts_path: 1,
  DELETE_foodstem_post_path: 2,
  PATCH_foodstem_post_path: 1,
  new_foodstem_post_path: 1,
  edit_foodstem_post_path: 1,
  POST_like_foodstem_post_path: 2,
  POST_undo_foodstem_post_path: 2,
  POST4CENTER_undo_foodstem_post_path: 1,
  likes_foodstem_post_path: 1,
  DELETE4CENTER_foodstem_post_path: 1,
  GET4CENTER_likes_foodstem_post_path: 1,
  POST4CENTER_like_foodstem_post_path: 1,
  POST_foodstem_post_comments_path: 1,
  POST4CENTER_repost_foodstem_post_path: 1,

  #Follower's paths
  user_followers_path: 2,
  user_follows_path: 2,
  DELETE_user_follower_path: 0,
  PATCH_user_follower_path: 0,
  POST_user_followers_path: 0,

  #Setting's paths
  user_settings_index_path: 0,
  edit_general_settings_path: 1,
  general_settings_path: 1,
  edit_payments_settings_path: 1,
  payments_settings_path: 1,
  cards_payments_settings_path: 1,
  seller_account_payments_settings_path: 1,

  notifications_path: 1,
  activities_path: 1,
}

Spree::Helpers::LinkToCol.add_paths map
