module Spree
  module PermittedAttributes
    @@store_attributes << :commision
  end
end