Rails.application.configure do
  # Settings specified here will take precedence over those in config/application.rb.

  # In the development environment your application's code is reloaded on
  # every request. This slows down response time but is perfect for development
  # since you don't have to restart the web server when you make code changes.
  config.cache_classes = false

  # Do not eager load code on boot.
  config.eager_load = false
  config.middleware.delete Rack::Lock

  # Show full error reports and disable caching.
  config.consider_all_requests_local       = true
  config.action_controller.perform_caching = true

  # Don't care if the mailer can't send.
  config.action_mailer.raise_delivery_errors = false
  config.action_mailer.delivery_method = :sendmail
  config.action_mailer.perform_deliveries = true
  config.action_mailer.default_url_options = {host: 'localhost:3001'}
  # Print deprecation notices to the Rails logger.
  config.active_support.deprecation = :log

  # Raise an error on page load if there are pending migrations.
  config.active_record.migration_error = :page_load

  # Debug mode disables concatenation and preprocessing of assets.
  # This option may cause significant delays in view rendering with a large
  # number of complex assets.
  config.assets.debug = true

  # Adds additional error checking when serving assets at runtime.
  # Checks for improperly declared sprockets dependencies.
  # Raises helpful error messages.
  config.assets.raise_runtime_errors = true

  config.action_mailer.default_url_options = { host: "localhost:3000" }
  config.action_mailer.delivery_method = :smtp
  config.action_mailer.smtp_settings = {
    address:              'smtp.sendgrid.com',
    port:                 587,
    domain:               'foodstems.com',
    user_name:            'foodstems',
    password:             '123456aa',
    authentication:       'plain',
    enable_starttls_auto: true,
    openssl_verify_mode: 'none'
  }
  # Raises error for missing translations
  # config.action_view.raise_on_missing_translations = true
  # 
  #Shippo api key
  config.shippo_api_key = 'shippo_test_9644791396ba4c2b85b35c8f13228577b0ee501d';
  config.payment_percent = 0.2
  config.stripe_secret_key  = 'sk_test_VMs2AzbfhiYP40xStUZPXeIz'
  config.stripe_publish_key = 'pk_test_ThScnqMlUy4E9xw2zvPzdkcx'
end
