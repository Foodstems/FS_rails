# Current deployment steps:

## Initial deployment
- `git clone`
- `bundle`
- set `RAILS_ENV=production`
- set SECRET_KEY_BASE to `rake secret`
- check Spree ssl settings
- `rake db:setup`
- `rake assets:precompile`
- `rails s`
- Restart rails

## Deployment of newer version
- `git pull`
- `bundle`
- `rake db:migrate`
- `rake assets:precompile`
- `rails s`
