# This file contains loading seed for Spree::Engine and executes only once after init database by following command:
#   rake db:seed

# If you need load seed with additional data then edit file 'db/seeds.rb' in extension's gem, create file 'filename.seeds.rb'
# in directory 'db/seeds' with following content:
#   ExtensionModuleName::Engine.load_seed if defined?(ExtensionModuleName)
# And then run:
#   rake db:seed:filename


Spree::Core::Engine.load_seed if defined?(Spree::Core)
Spree::Auth::Engine.load_seed if defined?(Spree::Auth)

Spree::User.admin.first.confirm!

