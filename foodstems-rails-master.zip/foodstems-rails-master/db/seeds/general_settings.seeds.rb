require 'highline/import'
require 'uri'
class << self
  def prompt_for_site_name(default_value = 'Foodstems')
    site_name = default_value
    unless ENV['AUTO_ACCEPT']
      site_name = ask('Site name: ') do |q|
        q.echo = true
        q.default = default_value
        q.validate = /^(|.{1,255})$/
        q.responses[:not_valid] = 'Invalid name. Must be from 1 to 255 characters long.'
        q.whitespace = :strip
      end
    end
    site_name
  end

  def prompt_for_site_url(default_value = 'http://foodstem.maginfo.com/')
    site_url = default_value
    unless ENV['AUTO_ACCEPT']
      site_url = ask('Site URL: ') do |q|
        q.echo = true
        q.default = default_value
        # Check that URL is correct
        q.validate = URI::regexp(:http)
        q.responses[:not_valid] = 'Invalid URL.'
      end
    end
    site_url
  end

  def prompt_for_mail_from_address(default_value = 'no-reply@foodstem.maginfo.com')
    mail_from_address = default_value
    unless ENV['AUTO_ACCEPT']
      mail_from_address = ask('Mail from address (Automated emails will be delivered from this address): ') do |q|
        q.echo = true
        q.default = default_value
        q.validate = URI::MailTo::EMAIL_REGEXP
        q.responses[:not_valid] = 'Invalid email.'
      end
    end
    mail_from_address
  end
end

store = Spree::Store.find_or_create_by(code: 'spree')
attributes = {
  name: prompt_for_site_name,
  url: prompt_for_site_url,
  mail_from_address: prompt_for_mail_from_address
}
store.update_attributes(attributes)
store.save!