require 'highline/import'
require 'uri'

class << self

  def prompt_for_attr(name, default_value)
    environment = default_value
    unless ENV['AUTO_ACCEPT']
      environment = ask("#{name}: ") do |q|
        q.echo = true
        q.default = default_value
      end
    end
    environment
  end

end


Spree::AuthenticationMethod.where(provider: :facebook).first_or_create do |a|
  a.environment = :production
  a.api_key = prompt_for_attr("Facebook auth application's API key", '135722800257500')
  a.api_secret = prompt_for_attr("Facebook auth application's API secret", 'f8cdc37f868dbda6a1c59e4c5d025913')
  a.active = true
end

Spree::AuthenticationMethod.where(provider: :linkedin).first_or_create do |a|
  a.environment = :production
  a.api_key = prompt_for_attr("LinkedIn auth application's API key", '78jzx6vnplkii0')
  a.api_secret = prompt_for_attr("LinkedIn auth application's API secret", '0lb1AUhdHavcoYtC')
  a.active = true
end
