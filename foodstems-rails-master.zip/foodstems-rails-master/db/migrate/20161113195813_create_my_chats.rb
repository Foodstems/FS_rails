class CreateMyChats < ActiveRecord::Migration
  def change
    create_table :my_chats do |t|
      t.string :message

      t.timestamps
    end
  end
end
