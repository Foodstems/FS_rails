class ChangeColumnContentToFoodstemDisputeOrders < ActiveRecord::Migration
  def change
  	change_column :foodstem_dispute_orders, :content, :text
  end
end
