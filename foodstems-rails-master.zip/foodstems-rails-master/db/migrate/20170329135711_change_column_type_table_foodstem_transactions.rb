class ChangeColumnTypeTableFoodstemTransactions < ActiveRecord::Migration
  def change
  	rename_column :foodstem_transactions, :type, :transaction_type
  end
end
