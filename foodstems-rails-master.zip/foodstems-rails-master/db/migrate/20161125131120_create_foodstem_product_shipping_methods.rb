class CreateFoodstemProductShippingMethods < ActiveRecord::Migration
  def change
    create_table :foodstem_product_shipping_methods do |t|
    	t.references :spree_products
    	t.references :spree_shipping_methods
    end
  end
end
