class RenameReviewableProductIdToProductIdInSpreeReviews < ActiveRecord::Migration
  def change
    rename_column :spree_reviews, :reviewable_product_id, :product_id
  end
end
