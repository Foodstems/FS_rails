class AddOptionsToFoodstemNotifications < ActiveRecord::Migration
  def change
    add_column :foodstem_notifications, :option1, :integer
    add_column :foodstem_notifications, :option2, :string
  end
end
