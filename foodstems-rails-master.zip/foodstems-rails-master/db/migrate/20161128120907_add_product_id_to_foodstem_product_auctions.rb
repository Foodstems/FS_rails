class AddProductIdToFoodstemProductAuctions < ActiveRecord::Migration
  def change
  	add_column :foodstem_product_auctions, :product_id, :integer
  end
end
