class AddColumnCommissionToSpreeStores < ActiveRecord::Migration
  def change
  	add_column :spree_stores, :commision, :numeric, default: 0
  end
end
