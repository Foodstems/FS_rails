class AddConfirmedToSpreeOrders < ActiveRecord::Migration
  def change
  	add_column :spree_orders, :confirmed, :numeric, default: 0
  end
end
