class CreateFoodstemDisputeOrders < ActiveRecord::Migration
  def change
    create_table :foodstem_dispute_orders do |t|
    	t.timestamps
    	t.references :order
    	t.references :user
    	t.string :accepted, default:'new'
    end
  end
end
