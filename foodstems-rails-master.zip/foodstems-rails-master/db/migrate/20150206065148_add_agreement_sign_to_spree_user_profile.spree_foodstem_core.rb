# This migration comes from spree_foodstem_core (originally 20150206064743)
class AddAgreementSignToSpreeUserProfile < ActiveRecord::Migration
  def change
    add_column :spree_user_profiles, :agreement_sign, :boolean, null: false, default: false
  end
end
