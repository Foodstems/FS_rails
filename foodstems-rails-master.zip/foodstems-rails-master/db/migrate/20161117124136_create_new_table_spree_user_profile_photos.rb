class CreateNewTableSpreeUserProfilePhotos < ActiveRecord::Migration
  def change
    create_table :spree_user_profile_photos do |t|
    	t.integer :profile_id
    	t.string :photo
    end
  end
end
