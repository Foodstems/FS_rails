# This migration comes from spree_foodstem_shop (originally 20150416052732)
class CreateFoodstemMerchants < ActiveRecord::Migration
  def change
    create_table :foodstem_merchants do |t|
      t.references :user, index: true, null: false
      t.string :braintree_id, null: false
      t.integer :destination, null: false
      t.string :first_name, null: false
      t.string :last_name, null: false
      t.date :date_of_birth, null: false
      t.string :email, null: false
      t.string :mobile_phone
      t.string :account_number, null: false
      t.string :routing_number, null: false
      t.string :location, null: false
      t.decimal :lat, null: false
      t.decimal :lng, null: false
      t.string :street_address, null: false
      t.string :locality, null: false
      t.string :region, null: false
      t.string :postal_code, null: false

      t.timestamps
    end
  end
end
