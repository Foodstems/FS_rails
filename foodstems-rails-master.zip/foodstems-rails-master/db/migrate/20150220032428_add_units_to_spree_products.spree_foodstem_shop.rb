# This migration comes from spree_foodstem_shop (originally 20150220032235)
class AddUnitsToSpreeProducts < ActiveRecord::Migration
  def change
    add_column :spree_products, :base_units, :string
    add_column :spree_products, :display_units, :string
    add_column :spree_products, :min_lot, :integer
    add_column :spree_products, :lot_quantifier, :integer
  end
end
