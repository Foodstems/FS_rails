# This migration comes from spree_foodstem_core (originally 20150213035835)
class CreateSpreeSocialRoles < ActiveRecord::Migration
  def change
    create_table :spree_social_roles do |t|
      t.string :name, null: false
      t.text :description

      t.timestamps
    end
  end
end
