# This migration comes from spree_foodstem_shop (originally 20150420055449)
class ChangeFoodstemMerchantsDestination < ActiveRecord::Migration
  def change
    change_column_null :foodstem_merchants, :destination, true
    change_column :foodstem_merchants, :destination, :text
    change_column_default :foodstem_merchants, :destination, 'bank'
  end
end
