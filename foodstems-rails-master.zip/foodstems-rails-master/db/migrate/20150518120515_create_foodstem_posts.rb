class CreateFoodstemPosts < ActiveRecord::Migration
  def change
    create_table :foodstem_posts do |t|
      t.references :user, index: true, null: false
      t.text :text, null: false
      t.boolean :deleted, null: false, default: false

      t.timestamps
    end
  end
end
