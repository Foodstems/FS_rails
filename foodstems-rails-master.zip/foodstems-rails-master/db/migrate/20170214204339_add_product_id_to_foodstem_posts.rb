class AddProductIdToFoodstemPosts < ActiveRecord::Migration
  def change
  	add_column :foodstem_posts, :product_id, :integer
  end
end
