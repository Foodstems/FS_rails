class RenameTypeInFoodstemTicketToKind < ActiveRecord::Migration
  def change
    rename_column :foodstem_tickets, :type, :kind
  end
end
