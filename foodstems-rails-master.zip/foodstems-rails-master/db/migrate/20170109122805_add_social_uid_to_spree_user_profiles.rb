class AddSocialUidToSpreeUserProfiles < ActiveRecord::Migration
  def change
  	add_column :spree_user_profiles, :social_uid, :string
  end
end
