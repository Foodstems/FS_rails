class AddColumnBalanceToSpreeUsers < ActiveRecord::Migration
  def change
  		add_column :spree_users, :balance, :numeric, default: 0
  end
end
