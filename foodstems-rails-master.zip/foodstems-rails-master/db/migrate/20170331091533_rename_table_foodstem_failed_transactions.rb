class RenameTableFoodstemFailedTransactions < ActiveRecord::Migration
  def change
  	  rename_table :table_foodstem_failed_transactions, :foodstem_failed_transactions
  end
end
