class CreateProductAuctions < ActiveRecord::Migration
  def change
    create_table :product_auctions do |t|
    	t.integer :lenght_days
    	t.integer :lenght_hours
    	t.integer :buy_now, default: 0
    	t.decimal :buy_now_total_price, precision: 10, scale: 2, default: 0.0, null: false
    	t.decimal :units_for_sale, precision: 10, scale:2
    	t.timestamps
    end
  end
end
