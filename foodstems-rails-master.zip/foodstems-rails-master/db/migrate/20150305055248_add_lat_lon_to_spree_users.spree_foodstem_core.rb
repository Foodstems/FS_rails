# This migration comes from spree_foodstem_core (originally 20150305054821)
class AddLatLonToSpreeUsers < ActiveRecord::Migration
  def change
    add_column :spree_users, :lat, :decimal
    add_column :spree_users, :lng, :decimal

    add_earthdistance_index :spree_users
  end
end
