class CreateFoodstemMessages < ActiveRecord::Migration
  def change
    create_table :foodstem_messages do |t|
      t.references :sender, null: false
      t.references :receiver
      t.references :conference
      t.string     :title
      t.text       :text, null: false
      t.boolean    :is_sender_deleted, null: false, default: false
      t.boolean    :is_receiver_deleted, null: false, default: false

      t.timestamps
    end
  end
end
