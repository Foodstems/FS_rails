class AddSpreeProductAddresses < ActiveRecord::Migration
   def change
    create_table :spree_product_addresses do |t|
    	t.string :address
    	t.string :city
    	t.string :state
    	t.integer :zip
    	t.string :lat
    	t.string :lng
    	t.references :product, index: true, foreign_key: true

    	t.timestamps
    end
  end
end
