class AddShippoObjectIdToFoodstemOrderDeliveryMethods < ActiveRecord::Migration
  def change
  	add_column :foodstem_order_delivery_methods, :shippo_object_id, :string
  end
end
