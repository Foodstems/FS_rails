class AddDisplaySizeToProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :display_size, :string, default:""
  end
end
