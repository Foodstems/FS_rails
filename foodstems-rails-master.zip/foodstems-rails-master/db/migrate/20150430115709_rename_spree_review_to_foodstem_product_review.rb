class RenameSpreeReviewToFoodstemProductReview < ActiveRecord::Migration
  def change
    remove_index :spree_reviews, name: :index_spree_reviews_on_reviewable_id_and_reviewable_type
    rename_column :spree_reviews, :reviewable_id, :reviewable_product_id
    remove_column :spree_reviews, :reviewable_type
    add_index :spree_reviews, :reviewable_product_id
  end
end
