class RenamePostIdToRepostedPostIdInFoodstemPosts < ActiveRecord::Migration
  def change
    add_column :foodstem_posts, :reposted_post_id, :integer
  end
end
