class ChangeColumnAddressInProductAddresses < ActiveRecord::Migration
  def change
  	   rename_column :spree_product_addresses, :address, :address1
  end
end
