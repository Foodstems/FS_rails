class AddSeenTooFoodstemMessages < ActiveRecord::Migration
  def change
  	add_column :foodstem_messages, :seen, :timestamp
  end
end
