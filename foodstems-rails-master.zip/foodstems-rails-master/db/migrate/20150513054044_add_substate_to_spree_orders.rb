class AddSubstateToSpreeOrders < ActiveRecord::Migration
  def change
    add_column :spree_orders, :foodstem_substate, :string
    add_column :spree_orders, :disputed, :boolean, nil: false, default: false
  end
end
