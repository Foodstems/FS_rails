class AddFacebookConfirmToSpreeUserProfiles < ActiveRecord::Migration
  def change
  	add_column :spree_user_profiles, :social_confirm, :string
  end
end
