class CreateFoodstemConversations < ActiveRecord::Migration
  def change
    create_table :foodstem_conversations do |t|
      t.references :user, index: true, null: false
      t.references :interlocutor, null: false
      t.references :last_message
      t.string :last_message_title
      t.text :last_message_text
      t.timestamp :last_message_at

      t.timestamps
    end
  end
end
