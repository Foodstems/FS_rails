class DropFoodstemConversationInterlocutors < ActiveRecord::Migration
  def change
    drop_table :foodstem_conversation_interlocutors
    remove_column :foodstem_conversations, :name
    rename_column :foodstem_messages, :conversation_id, :conference_id
  end
end
