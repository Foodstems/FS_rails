# This migration comes from spree_foodstem_core (originally 20150206050017)
class CreateSpreeUserProfiles < ActiveRecord::Migration
  def change
    create_table :spree_user_profiles do |t|
      t.string :first_name
      t.string :last_name
      t.string :social_role
      t.references :user, index: true

      t.timestamps
    end
  end
end
