class AddColumnIsRefundedToSpreePayments < ActiveRecord::Migration
  def change
  	add_column :spree_payments, :is_refunded, :integer, default:0
  end
end
