class CreateFoodstemNotifications < ActiveRecord::Migration
  def change
    create_table :foodstem_notifications do |t|
      t.references :user, index: true, null: false
      t.references :source, polymorphic: true, index: true
      t.timestamp :deleted_at
      t.timestamps
    end
  end
end
