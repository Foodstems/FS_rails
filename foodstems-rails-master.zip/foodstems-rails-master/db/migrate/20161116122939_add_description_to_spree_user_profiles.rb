class AddDescriptionToSpreeUserProfiles < ActiveRecord::Migration
  def change
    add_column :spree_user_profiles, :description, :text
  end
end
