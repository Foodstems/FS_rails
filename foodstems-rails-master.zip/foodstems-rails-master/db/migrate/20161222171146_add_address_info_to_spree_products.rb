class AddAddressInfoToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :street1, :text
  	add_column :spree_products, :city, :text
  	add_column :spree_products, :state, :text
  	add_column :spree_products, :zip, :text
  end
end
