class AddParticipantsToFoodstemConferences < ActiveRecord::Migration
  def change
  	  	add_column :foodstem_conferences, :participants, :text

  end
end
