class ChangeColumnParcelWeigthToParcelWeight < ActiveRecord::Migration
  def change
  	rename_column :spree_products, :parcel_weigth, :parcel_weight
  end
end
