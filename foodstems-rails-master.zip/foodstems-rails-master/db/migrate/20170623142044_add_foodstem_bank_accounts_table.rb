class AddFoodstemBankAccountsTable < ActiveRecord::Migration
  def change
  	    create_table :foodstem_bank_accounts do |t|
  	    t.references :user, index:true
  	    t.string :bank_account_id
  	    t.integer :verified, default: 0
  	    t.string :verify_amount_1
  	    t.string :verify_amount_2
  	    t.integer :failed_verifications, default: 0
  	    t.integer :account_number
  	    t.integer :routing_number
  	    t.integer :name
  	    t.date :verification_date
    	t.timestamps
    end
  end
end
