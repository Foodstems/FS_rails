class FoodstemTransactionsDescriptionType < ActiveRecord::Migration
  def change
  	change_column(:foodstem_transactions, :description, :text)
  end
end
