class ChangeColumnNameFoodstemProductShippingMethods < ActiveRecord::Migration
  def change
  	rename_column :foodstem_product_shipping_methods, :spree_products_id, :product_id
  	rename_column :foodstem_product_shipping_methods, :spree_shipping_methods_id, :shipping_method_id
  end
end
