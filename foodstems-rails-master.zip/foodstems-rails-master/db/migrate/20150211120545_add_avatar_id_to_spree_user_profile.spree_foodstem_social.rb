# This migration comes from spree_foodstem_social (originally 20150211120507)
class AddAvatarIdToSpreeUserProfile < ActiveRecord::Migration
  def change
    add_reference :spree_user_profiles, :avatar, index: true
  end
end
