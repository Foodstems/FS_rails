class ChangeWidthAndInSpreeProducts < ActiveRecord::Migration
  def change
  	rename_column :spree_products, :heigth, :parcel_heigth
  	rename_column :spree_products, :width, :parcel_width
  	rename_column :spree_products, :length, :parcel_length
  end
end
