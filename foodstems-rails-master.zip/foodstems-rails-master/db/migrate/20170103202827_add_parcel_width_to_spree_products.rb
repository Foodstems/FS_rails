class AddParcelWidthToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :width, :integer
  	add_column :spree_products, :height, :integer
  	add_column :spree_products, :length, :integer
  end
end
