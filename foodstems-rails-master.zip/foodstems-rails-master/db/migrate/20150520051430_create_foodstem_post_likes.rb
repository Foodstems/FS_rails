class CreateFoodstemPostLikes < ActiveRecord::Migration
  def change
    create_table :foodstem_post_likes do |t|
      t.references :post, index: true, null: false
      t.references :user, index: true, null: false
      t.index [:post_id, :user_id]
      t.timestamps
    end
  end
end
