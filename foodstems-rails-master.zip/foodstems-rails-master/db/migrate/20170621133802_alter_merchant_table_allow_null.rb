class AlterMerchantTableAllowNull < ActiveRecord::Migration
  def change
  	  change_column_null :foodstem_merchants, :destination, true
  	  change_column_null :foodstem_merchants, :first_name, true
  	  change_column_null :foodstem_merchants, :last_name, true
  	  change_column_null :foodstem_merchants, :date_of_birth, true
  	  change_column_null :foodstem_merchants, :account_number, true
  	  change_column_null :foodstem_merchants, :routing_number, true
  	  change_column_null :foodstem_merchants, :location, true
  	  change_column_null :foodstem_merchants, :lat, true
  	  change_column_null :foodstem_merchants, :lng, true
  	  change_column_null :foodstem_merchants, :street_address, true
  	  change_column_null :foodstem_merchants, :locality, true
  	  change_column_null :foodstem_merchants, :region, true
  	  change_column_null :foodstem_merchants, :postal_code, true

  end
end
