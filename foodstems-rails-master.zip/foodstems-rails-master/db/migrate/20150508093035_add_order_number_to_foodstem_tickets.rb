class AddOrderNumberToFoodstemTickets < ActiveRecord::Migration
  def change
    remove_column :foodstem_tickets, :order_id
    add_column :foodstem_tickets, :order_number, :string
  end
end
