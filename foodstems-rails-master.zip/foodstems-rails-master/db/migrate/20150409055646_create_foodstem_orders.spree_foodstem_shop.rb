# This migration comes from spree_foodstem_shop (originally 20150406120113)
class CreateFoodstemOrders < ActiveRecord::Migration
  def change
    create_table :foodstem_orders do |t|
      t.references :consumer, index: true, null: false
      t.references :vendor, index: true, null: false
      t.references :variant, index: true, null: false
      t.integer :item_count, null: false
      t.decimal :total, precision: 10, scale: 2, null: false
      t.string :currency, null: false

      t.timestamps
    end
  end
end
