class AddRelistedColumnDefaultValueToSpreeProducts < ActiveRecord::Migration
  def change
  	change_column :spree_products, :relisted, :integer, :null => false, :default => 0
  end
end
