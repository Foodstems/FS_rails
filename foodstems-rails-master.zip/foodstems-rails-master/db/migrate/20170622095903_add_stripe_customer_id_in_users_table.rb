class AddStripeCustomerIdInUsersTable < ActiveRecord::Migration
  def change
  	add_column :spree_users, :stripe_acc_id, :string, default:""
  end
end
