class CreateFoodstemConferences < ActiveRecord::Migration
  def change
    create_table :foodstem_conferences do |t|
      t.string :name
      t.references :creator, index: true

      t.timestamps
    end
  end
end
