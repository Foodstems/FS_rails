class AddVendorIdToSpreeOrders < ActiveRecord::Migration
  def change
    add_column :spree_orders, :vendor_id, :integer
  end
end
