class AddEmailToProfilesTable < ActiveRecord::Migration
  def change
  	add_column :spree_user_profiles, :email, :string
  end
end
