class AddTaglineToSpreeUserProfiles < ActiveRecord::Migration
  def change
    add_column :spree_user_profiles, :tagline, :string, null: true
  end
end
