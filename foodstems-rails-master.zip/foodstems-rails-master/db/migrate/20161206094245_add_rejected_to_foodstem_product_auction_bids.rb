class AddRejectedToFoodstemProductAuctionBids < ActiveRecord::Migration
  def change
  		add_column :foodstem_product_auction_bids, :rejected, :integer, default: 0
  end
end
