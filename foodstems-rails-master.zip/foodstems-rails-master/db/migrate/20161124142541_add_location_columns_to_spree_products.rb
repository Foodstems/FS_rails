class AddLocationColumnsToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :location, :string
  	add_column :spree_products, :lat, :numeric
  	add_column :spree_products, :lng, :numeric
  end
end
