class RemoveProductIdColumnFromSpreeProductAddresses < ActiveRecord::Migration
  def change
  	remove_column :spree_product_addresses, :product_id
  	add_column :spree_product_addresses, :user_id, :integer, index:true
  end
end
