class AddDaysToSpreeShippingMethods < ActiveRecord::Migration
  def change
  	add_column :spree_shipping_methods, :days, :integer
  end
end
