class CreateFoodstemConversationInterlocutors < ActiveRecord::Migration
  def change
    create_table :foodstem_conversation_interlocutors do |t|
      t.references :conversation, index: true, null: false
      t.references :user, index: true, null: false
    end
  end
end
