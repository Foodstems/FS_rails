# This migration comes from spree_foodstem_shop (originally 20150401062121)
class CreateSpreeReviews < ActiveRecord::Migration
  def change
    create_table :spree_reviews do |t|
      t.references :user, index: true, null: false
      t.references :reviewable, polymorphic: true, index: true, null: false
      t.text :text
      t.float :rating, precision: 2, scale: 1
      t.datetime :deleted_at

      t.timestamps
    end
  end
end
