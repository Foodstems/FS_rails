class CreateFoodstemUserFeedbacks < ActiveRecord::Migration
  def change
    create_table :foodstem_feedbacks do |t|
      t.references :order, index: true
      t.references :user, index: true, null: false
      t.references :reviewable_user, index: true, null: false
      t.integer :user_role, null: false
      t.integer :rating
      t.text :text
      t.boolean :completed, null: false, default: false
      t.references :product, index: true

      t.timestamps
    end
  end
end
