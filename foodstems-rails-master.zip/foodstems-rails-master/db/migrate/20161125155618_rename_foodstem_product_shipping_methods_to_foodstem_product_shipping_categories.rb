class RenameFoodstemProductShippingMethodsToFoodstemProductShippingCategories < ActiveRecord::Migration
  def change
  	 rename_table :foodstem_product_shipping_methods, :foodstem_product_shipping_categories
  end
end
