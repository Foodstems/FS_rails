class AddPostToFoodstemPosts < ActiveRecord::Migration
  def change
    add_reference :foodstem_posts, :post, index: true
  end
end
