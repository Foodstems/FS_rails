class AddColumnIsProductChatToFoodstemConferences < ActiveRecord::Migration
  def change
  	add_column :foodstem_conferences, :is_product_chat, :integer, default:0
  end
end
