class CreateFoodstemFollowers < ActiveRecord::Migration
  def change
    create_table :foodstem_followers do |t|
      t.references :user, index: true
      t.references :follower, index: true

      t.timestamps
    end
  end
end
