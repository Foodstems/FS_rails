class AddColumnContentToFoodstemDisputeOrders < ActiveRecord::Migration
  def change
  	add_column :foodstem_dispute_orders, :content, :string
  end
end
