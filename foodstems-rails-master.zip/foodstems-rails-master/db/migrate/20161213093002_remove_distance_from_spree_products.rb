class RemoveDistanceFromSpreeProducts < ActiveRecord::Migration
  def up
  	remove_column :spree_products, :distance
  end
end
