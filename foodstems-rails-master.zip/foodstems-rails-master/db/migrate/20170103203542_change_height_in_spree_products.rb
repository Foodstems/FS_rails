class ChangeHeightInSpreeProducts < ActiveRecord::Migration
  def change
  	rename_column :spree_products, :height, :heigth
  end
end
