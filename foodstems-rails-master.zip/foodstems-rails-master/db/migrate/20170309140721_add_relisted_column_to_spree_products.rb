class AddRelistedColumnToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :relisted, :integer, relisted:0
  end
end
