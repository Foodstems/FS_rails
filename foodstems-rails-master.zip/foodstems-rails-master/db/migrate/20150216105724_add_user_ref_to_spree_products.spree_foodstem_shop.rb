# This migration comes from spree_foodstem_shop (originally 20150216105714)
class AddUserRefToSpreeProducts < ActiveRecord::Migration
  def change
    add_reference :spree_products, :user, index: true
  end
end
