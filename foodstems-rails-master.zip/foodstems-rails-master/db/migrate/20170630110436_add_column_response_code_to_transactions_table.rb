class AddColumnResponseCodeToTransactionsTable < ActiveRecord::Migration
  def change
  	add_column :foodstem_transactions, :response_code, :string, default:""
  end
end
