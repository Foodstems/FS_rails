class CreateFoodstemTickets < ActiveRecord::Migration
  def change
    create_table :foodstem_tickets do |t|
      t.references :user, index: true, null: false
      t.text :text, null: false
      t.string :title, null: false
      t.string :type, null: false
      t.references :order
      t.references :support_worker
      t.boolean :is_support_worker_read, null: false, default: false

      t.timestamps
    end
  end
end
