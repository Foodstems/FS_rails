class FoodstemMerchantsChangeLastName < ActiveRecord::Migration
  def change
  	change_column_null(:foodstem_merchants, :last_name, true)
  end
end
