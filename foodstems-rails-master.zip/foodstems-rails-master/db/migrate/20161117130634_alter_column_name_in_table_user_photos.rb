class AlterColumnNameInTableUserPhotos < ActiveRecord::Migration
  def change
  	 rename_column :spree_user_profile_photos, :profile_id, :user_profile_id
  end
end
