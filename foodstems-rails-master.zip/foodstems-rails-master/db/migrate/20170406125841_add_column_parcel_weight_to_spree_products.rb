class AddColumnParcelWeightToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :parcel_weigth, :float, default:0
  end
end
