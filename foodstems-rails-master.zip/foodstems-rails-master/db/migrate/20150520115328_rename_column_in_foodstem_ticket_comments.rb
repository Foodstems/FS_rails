class RenameColumnInFoodstemTicketComments < ActiveRecord::Migration
  def change
    change_table :foodstem_ticket_comments do |t|
      t.rename :support_worker_id, :user_id
      t.boolean :is_support_worker, default: false
    end
  end
end
