class CreateFoodstemOrderDeliveryMethods < ActiveRecord::Migration
  def change
    create_table :foodstem_order_delivery_methods do |t|
    	t.references :order
    	t.references :shipping_method
    end
  end
end
