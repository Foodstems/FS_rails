class AddBirthdayToSpreeUserProfiles < ActiveRecord::Migration
  def change
  	add_column :spree_user_profiles, :dob_y, :integer
  	add_column :spree_user_profiles, :dob_m, :integer
  	add_column :spree_user_profiles, :dob_d, :integer
  end
end
