class AlterTableFoodstemBankAccountsAddColumnBankAccountToken < ActiveRecord::Migration
  def change
  	add_column :foodstem_bank_accounts, :bank_account_token, :string, default:""
  end
end
