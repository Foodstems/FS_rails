class ChangeParcelColumnsInSpeeProducts < ActiveRecord::Migration
  def change
  	change_column :spree_products, :parcel_width, :float
  	change_column :spree_products, :parcel_heigth, :float
  	change_column :spree_products, :parcel_length, :float
  end
end
