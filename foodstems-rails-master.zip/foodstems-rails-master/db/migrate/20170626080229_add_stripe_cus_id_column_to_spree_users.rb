class AddStripeCusIdColumnToSpreeUsers < ActiveRecord::Migration
  def change
  	add_column :spree_users, :stripe_cus_id, :string, default:""
  end
end
