class AddAccessTokenColumnInProfiles < ActiveRecord::Migration
  def change
  	add_column :spree_user_profiles, :access_token, :text
  end
end
