class AddColumnUserIdToSpreePayments < ActiveRecord::Migration
  def change
  	add_column :spree_payments, :user_id, :integer
  end
end
