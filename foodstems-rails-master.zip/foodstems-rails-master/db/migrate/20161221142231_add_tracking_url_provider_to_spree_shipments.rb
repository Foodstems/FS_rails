class AddTrackingUrlProviderToSpreeShipments < ActiveRecord::Migration
  def change
  	add_column :spree_shipments, :tracking_url_provider, :text
  	add_column :spree_shipments, :label_url, :text
  	add_column :spree_shipments, :shippo_object_id, :string
  end
end
