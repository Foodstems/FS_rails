class AddColumnDisputedToSpreePayments < ActiveRecord::Migration
  def change
  	add_column :spree_payments, :is_disputed, :integer, default:0
  end
end
