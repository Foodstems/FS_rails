# This migration comes from spree_foodstem_core (originally 20150306060426)
class AddLocationToSpreeUsers < ActiveRecord::Migration
  def change
    add_column :spree_users, :location, :string
  end
end
