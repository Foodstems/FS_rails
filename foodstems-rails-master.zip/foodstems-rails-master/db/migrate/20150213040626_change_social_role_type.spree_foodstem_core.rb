# This migration comes from spree_foodstem_core (originally 20150213040317)
class ChangeSocialRoleType < ActiveRecord::Migration
  def change
    remove_column :spree_user_profiles, :social_role
    add_reference :spree_user_profiles, :social_role, index: true
  end
end
