class AddAddressIdToProduct < ActiveRecord::Migration
  def change
  		add_column :spree_products, :address_id, :integer
  end
end
