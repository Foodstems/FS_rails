class AddDistanceToSpreeProducts < ActiveRecord::Migration
  def change
  		add_column :spree_products, :distance, :numeric, default: 0
  end
end
