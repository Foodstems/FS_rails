class AddLikesToFoodstemPosts < ActiveRecord::Migration
  def change
    add_column :foodstem_posts, :number_of_likes, :integer, null: false, default: 0
  end
end
