class RenameColumnPaymentsIdTableFailedTransactions < ActiveRecord::Migration
  def change
  	rename_column :foodstem_failed_transactions, :payments_id, :payment_id
  end
end
