class AddColumnDirectionToFoodstemTransactions < ActiveRecord::Migration
  def change
  	add_column :foodstem_transactions, :diresction, :string
  end
end
