class ChangeColumnShippingMethodIdInFoodstemProductShippingCategories < ActiveRecord::Migration
  def change
  	rename_column :foodstem_product_shipping_categories, :shipping_method_id, :shipping_category_id
  end
end
