class AddPhoneNumberToSpreeUserProfiles < ActiveRecord::Migration
  def change
    add_column :spree_user_profiles, :phone_number, :string
  end
end
