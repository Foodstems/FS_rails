class AddConferenceToFoodstemConversations < ActiveRecord::Migration
  def change
    add_reference :foodstem_conversations, :conference, index: true
  end
end
