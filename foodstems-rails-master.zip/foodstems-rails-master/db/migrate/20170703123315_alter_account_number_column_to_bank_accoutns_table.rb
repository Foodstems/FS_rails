class AlterAccountNumberColumnToBankAccoutnsTable < ActiveRecord::Migration
  def change
  	  	change_column :foodstem_bank_accounts, :account_number, :string, default:""

  end
end
