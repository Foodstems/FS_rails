class RenameConferenceInFoodstemMessagesToConversation < ActiveRecord::Migration
  def change
    rename_column :foodstem_messages, :conference_id, :conversation_id
  end
end
