class CreateFoodstemAddresses < ActiveRecord::Migration
  def change
    create_table :foodstem_addresses do |t|
      t.references :user, null: false
      t.references :address, null: false
      t.timestamps
    end
  end
end
