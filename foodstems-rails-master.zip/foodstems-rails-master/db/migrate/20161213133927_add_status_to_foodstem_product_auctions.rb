class AddStatusToFoodstemProductAuctions < ActiveRecord::Migration
  def change
  	add_column :foodstem_product_auctions, :status, :integer, default: 0
  end
end
