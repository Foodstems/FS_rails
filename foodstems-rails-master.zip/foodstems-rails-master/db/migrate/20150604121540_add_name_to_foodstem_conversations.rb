class AddNameToFoodstemConversations < ActiveRecord::Migration
  def change
    add_column :foodstem_conversations, :name, :string
  end
end
