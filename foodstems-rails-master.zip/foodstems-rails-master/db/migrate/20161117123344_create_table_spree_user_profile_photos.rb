class CreateTableSpreeUserProfilePhotos < ActiveRecord::Migration
  def change
    create_table :table_spree_user_profile_photos do |t|
    	t.integer :profile_id
    	t.string :photo
    end
  end
end
