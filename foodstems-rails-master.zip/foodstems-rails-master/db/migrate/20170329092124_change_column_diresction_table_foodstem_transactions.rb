class ChangeColumnDiresctionTableFoodstemTransactions < ActiveRecord::Migration
  def change
  	rename_column :foodstem_transactions, :diresction, :direction
  end
end
