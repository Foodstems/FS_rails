class CreateFoodstemProductAuctionBids < ActiveRecord::Migration
  def change
    create_table :foodstem_product_auction_bids do |t|
    	t.integer :product_id
    	t.integer :product_auction_id
    	t.integer :user_id
 		t.decimal :bid, precision: 10, scale: 2, default: 0.0, null: false

 		t.timestamps
    end
  end
end
