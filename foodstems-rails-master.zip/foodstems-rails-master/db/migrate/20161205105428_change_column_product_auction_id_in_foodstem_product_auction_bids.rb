class ChangeColumnProductAuctionIdInFoodstemProductAuctionBids < ActiveRecord::Migration
  def change
  		rename_column :foodstem_product_auction_bids, :product_auction_id, :auction_id
  end
end
