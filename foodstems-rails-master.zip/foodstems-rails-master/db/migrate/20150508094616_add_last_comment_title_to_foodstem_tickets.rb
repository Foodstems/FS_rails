class AddLastCommentTitleToFoodstemTickets < ActiveRecord::Migration
  def change
    add_column :foodstem_tickets, :last_comment_title, :string
    add_column :foodstem_tickets, :last_comment_text, :text
    add_column :foodstem_tickets, :last_comment_created_at, :timestamp
  end
end
