class CreateFoodstemFavoriteVendors < ActiveRecord::Migration
  def change
    create_table :foodstem_favorite_vendors do |t|
      t.references :user, null: false, index: true
      t.references :vendor, null: false, index: true
      t.timestamps
    end
  end
end
