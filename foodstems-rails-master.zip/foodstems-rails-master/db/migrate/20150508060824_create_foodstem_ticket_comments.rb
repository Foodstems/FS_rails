class CreateFoodstemTicketComments < ActiveRecord::Migration
  def change
    create_table :foodstem_ticket_comments do |t|
      t.references :ticket, index: true, null: false
      t.text :text, null: false
      t.references :support_worker
      t.boolean :is_user_read, null: false, default: false
      t.boolean :is_support_worker_read, null: false, default: false

      t.timestamps
    end
  end
end
