class AddLocationToProductAddresses < ActiveRecord::Migration
  def change
  	add_column :spree_product_addresses, :location, :string
  end
end
