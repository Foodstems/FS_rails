class AddSocialIdUsersTable < ActiveRecord::Migration
  def change
  	add_column :spree_users, :social_uid, :integer, default:0
  end
end
