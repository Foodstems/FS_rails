class ChangeStreet1ToAddress1 < ActiveRecord::Migration
  def change
  	rename_column :spree_products, :street1, :address1
  end
end
