class CreateFoodstemPostComments < ActiveRecord::Migration
  def change
    create_table :foodstem_post_comments do |t|
      t.references :user, index: true, null: false
      t.references :post, index: true, null: false
      t.text :text, null: false
      t.boolean :deleted, null: false, default: false

      t.timestamps
    end
  end
end
