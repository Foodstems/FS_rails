class CreateTableFoodstemFailedTransactions < ActiveRecord::Migration
  def change
    create_table :table_foodstem_failed_transactions do |t|
    	t.timestamps
    	t.string :response_code
    	t.string :status
    	t.references :payments
    end
  end
end
