class ChangeDefaultSettingsForColumnParcelWeight < ActiveRecord::Migration
  def change
  	change_column_default :spree_products, :parcel_weight, nil
  end
end
