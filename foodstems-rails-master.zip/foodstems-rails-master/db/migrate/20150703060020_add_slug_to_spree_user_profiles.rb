class AddSlugToSpreeUserProfiles < ActiveRecord::Migration
  def change
    add_column :spree_user_profiles, :slug, :string, unique: true, null: true
    add_index :spree_user_profiles, :slug
  end
end
