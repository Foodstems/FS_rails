class AlterTableFoodstemBankAccountsChangeNameType < ActiveRecord::Migration
  def change
  	change_column :foodstem_bank_accounts, :name, :string
  end
end
