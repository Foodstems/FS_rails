class AddInitStockToSpreeProducts < ActiveRecord::Migration
  def change
  	add_column :spree_products, :init_stock, :integer
  end
end
