class RenameTableFoodstemTransactions < ActiveRecord::Migration
  def change
  	    rename_table :table_foodstem_transactions, :foodstem_transactions
  end
end
