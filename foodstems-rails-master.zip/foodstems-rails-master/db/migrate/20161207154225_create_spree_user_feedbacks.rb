class CreateSpreeUserFeedbacks < ActiveRecord::Migration
  def change
    create_table :spree_user_feedbacks do |t|

      	t.references :user, index: true, null: false
      	t.references :reviewable_user, index: true, null: false
      	t.integer :user_role, null: false
      	t.integer :rating
      	t.text :text
      	t.boolean :completed, null: false, default: false
        t.timestamps
        
    end
  end
end
