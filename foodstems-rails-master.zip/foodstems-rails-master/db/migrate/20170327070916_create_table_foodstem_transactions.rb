class CreateTableFoodstemTransactions < ActiveRecord::Migration
  def change
    create_table :table_foodstem_transactions do |t|
    
    	t.references :user, index:true
    	t.integer :amount
    	t.string :type
    	t.string :description
    	t.string :order_number
    	t.timestamps
    end
  end
end
