class AddColumnChargeToSpreeOrders < ActiveRecord::Migration
  def change
  	add_column :spree_orders, :charged, :integer, default: 0
  end
end
