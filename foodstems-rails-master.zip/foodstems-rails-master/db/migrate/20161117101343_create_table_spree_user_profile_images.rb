class CreateTableSpreeUserProfileImages < ActiveRecord::Migration
  def change
    create_table :spree_user_profile_images do |t|
    	t.integer :profile_id
    	t.integer :image
    end
  end
end
