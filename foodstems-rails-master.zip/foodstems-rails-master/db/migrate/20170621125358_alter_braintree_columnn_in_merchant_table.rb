class AlterBraintreeColumnnInMerchantTable < ActiveRecord::Migration
  def change
  	rename_column :foodstem_merchants, :braintree_id, :stripe_account_id
  end
end
