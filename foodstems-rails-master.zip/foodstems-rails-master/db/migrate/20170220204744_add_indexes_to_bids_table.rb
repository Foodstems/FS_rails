class AddIndexesToBidsTable < ActiveRecord::Migration
  def change
  	 add_index :foodstem_product_auction_bids, :user_id
  	 add_index :foodstem_product_auction_bids, :product_id
  	 add_index :foodstem_product_auction_bids, :auction_id
  end
end
