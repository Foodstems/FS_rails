Spree::Core::Engine.routes.draw do
  # Add your extension routes here
  # Hack for spree_social #150
  # FIXME: check whether they fixed this and remove
  #  devise_for :spree_user,
  #             class_name: Spree::User,
  #             path_prefix: :user,
  #             skip: [:sessions, :registrations, :passwords, :unlocks, :omniauth_callbacks],
  #             controllers: { confirmations: 'spree/user_confirmations' }
  
  namespace :admin do
    resources :disputes
  end

  post '/notifications/update_notifications', to:'foodstem/notifications#update_notifications'
  resources :notifications, controller: 'foodstem/notifications', only: [:index] do
    get :load, on: :collection

  end
  

  get '/pages/report_problem', to: 'custom_pages#report_problem'

  get '/app/', to: 'foodstem#index', as: 'foodstem'
  get '/foodstem/:id/products', to: 'foodstem#user_products'
  #get '/foodstem/:id/products', to: 'foodstem#user_products'
  get '/app/:id/orders', to: 'foodstem#user_orders'
  get '/app/:column', to: 'foodstem#index'
  get '/app/:column/:l1', to: 'foodstem#index'
  get '/app/:column/:l1/:l2', to: 'foodstem#index'
  get '/app/:column/:l1/:l2/:l3', to: 'foodstem#index'
  get '/app/:column/:l1/:l2/:l3/:l4', to: 'foodstem#index'
  # post '/new_session', to: 'spree/user_sessions#create', as: 'new_spree_user_session'
  get '/registration', to: 'user_profiles#quiz_step1', as: 'quiz_step1'
  match '/quiz_step1', to: 'user_profiles#quiz_step1_submit', via: [:post, :put, :patch], as: 'quiz_step1_submit'

  post '/user_profiles/update_avatar_on_register', to: 'user_profiles#update_avatar_on_register'

  get '/quiz_step2', to: 'user_profiles#quiz_step2', as: 'quiz_step2'
  match '/quiz_step2', to: 'user_profiles#quiz_step2_submit', via: [:post, :put, :patch], as: 'quiz_step2_submit'



  resource :settings, as: '', module: :settings do
    resource :general_settings, only: [:show, :update] do
      get 'cancel_change_email', to: 'general_settings#cancel_change_email'
    end
    resource :payments_settings, only: [:show, :update] do
      get 'cards', to: 'payments_settings#cards'
      get 'seller_account', to: 'payments_settings#seller_account'
    end
    # resource :user_settings, only: [:index], path: ''
  end

  #get '/quiz_step3', to: 'user_profiles#quiz_step3', as: 'quiz_step3'
  #match '/quiz_step3', to: 'user_profiles#quiz_step3_submit', via: [:post, :put, :patch], as: 'quiz_step3_submit'

end
