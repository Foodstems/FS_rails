Spree::Config[:layout] = false
Spree::Config[:require_master_price] = true
Spree::Config[:auto_capture] = false
Spree::Config[:track_inventory_levels] = true
Spree::Config[:default_country_id] = 232
