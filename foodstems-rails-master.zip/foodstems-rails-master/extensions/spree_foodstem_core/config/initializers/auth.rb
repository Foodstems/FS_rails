require 'omniauth-linkedin'
require 'spree_social'

Spree::Auth::Config[:confirmable] = true
SpreeSocial::OAUTH_PROVIDERS << ['LinkedIn', 'linkedin', 'linkedin']
SpreeSocial.init_provider('linkedin')
