class CreateJoinTableUserProfilesSocialRoles < ActiveRecord::Migration
  def change
    create_join_table :spree_user_profiles, :spree_social_roles do |t|
      # t.index [:spree_user_profile_id, :spree_social_role_id]
      # t.index [:spree_social_role_id, :spree_user_profile_id]
    end
  end
end
