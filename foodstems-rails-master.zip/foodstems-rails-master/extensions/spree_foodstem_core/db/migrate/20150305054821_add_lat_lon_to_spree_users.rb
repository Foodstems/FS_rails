class AddLatLonToSpreeUsers < ActiveRecord::Migration
  def change
    add_column :spree_users, :lat, :decimal
    add_column :spree_users, :lng, :decimal

    add_earthdistance_index :spree_users
  end
end
