class AddLocationToSpreeUsers < ActiveRecord::Migration
  def change
    add_column :spree_users, :location, :string
  end
end
