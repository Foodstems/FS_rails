Spree::SocialRole.where(name: 'Producer').first_or_create
Spree::SocialRole.where(name: 'Consumer').first_or_create
