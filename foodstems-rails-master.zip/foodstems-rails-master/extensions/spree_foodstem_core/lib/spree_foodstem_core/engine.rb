module SpreeFoodstemCore
  class Engine < Rails::Engine
    require 'spree/core'
    isolate_namespace Spree
    engine_name 'spree_foodstem_core'

    # use rspec for tests
    config.generators do |g|
      g.test_framework :rspec
    end

    def self.activate
      filelist = Dir.glob(File.join(File.dirname(__FILE__), '../../app/helpers/*.rb'))
      filelist += Dir.glob(File.join(File.dirname(__FILE__), '../../app/**/*_decorator*.rb'))
      filelist.each do |c|
        Rails.configuration.cache_classes ? require(c) : load(c)
      end
    end

    config.to_prepare &method(:activate).to_proc
  end
end
