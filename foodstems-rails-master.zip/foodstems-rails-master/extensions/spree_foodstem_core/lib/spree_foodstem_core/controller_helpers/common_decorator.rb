class << Spree::Core::ControllerHelpers::Common
  alias_method :included_old, :included
  def included(base)
    self.included_old(base)
    base.class_eval do
      def get_layout
        layout ||= Spree::Config[:layout]
        if layout == 'false'
          layout = false
        end
        if layout
          layout
        elsif devise_controller?
          'greetings_layout'
        else
          layout
        end
      end
    end
  end
end
