// Placeholder manifest file.
// the installer will append this file to the app vendored assets here: vendor/assets/javascripts/spree/frontend/all.js'
//= require 'jquery'
//= require 'bootstrap-sprockets'
//= require 'spree/frontend/core'
//= require 'spree/frontend/no-conflict-bootstrap'
//= require 'spree/frontend/ajax_column_loader'
//= require 'spree/frontend/notifications'
//= require 'spree/frontend/settings'
//= require 'jquery_ujs'
//= require 'jquery-ui'
//= require 'jquery.remotipart'
//= require 'sweet-alert'
//= require 'owl.carousel'
//= require jquery-fileupload/index
//= require 'spree/frontend/util'
//= require 'spree/frontend/timers'
//= require 'spree/frontend/columns'
//= require 'spree/frontend/show_more'
//= require 'spree/frontend/jquery.countdown.min'
//= require fancybox
//= require 'spree/frontend/masked-input.min.js'
//= require 'spree/frontend/bids'
//= require socket.io
//= require parsley
//= require 'spree/frontend/payment_methods.js'
//= require 'spree/frontend/jquery.maskMoney.min.js'
$.ajaxSetup({
  headers: {
    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
  }
});

Foodstem.WAITING_SPINNER_HTML = '<div class="my-wait"><div class="my-wait-spinner-wrap"><i class="fa fa-spinner fa-pulse fa-4x my-wait-spinner"></i></div></div>';

$(function() {

  var $links = $('a[data-remote=\'true\']');
  var $forms = $('form[data-remote="true"]');

  $forms.on('submit', function() {
    $('#column-' + $(this).data('target-column')).append(Foodstem.WAITING_SPINNER_HTML);
  });

  $links.on('click', function(event) {

    if (event.ctrlKey) {
        event.preventDefault();
        return false;
    }

    if(event.button == 1 || event.button == 2)
    {
      event.preventDefault();
      return false;
    }

    $('#column-' + $(this).data('target-column')).append(Foodstem.WAITING_SPINNER_HTML);

  });

  $links.on('contextmenu', function() {
    return false;
  });

  $('ul.nav li.dropdown#profile_dropdown').hover(function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
      $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
  });

  $(document).on("click", ".message-item", function() {
      $(this).removeClass("chat_new_message")
  })


  /*
  var socket = io.connect("http://localhost:8005/");
  socket.on('connect', function() {
    console.log('connected');
  });


  socket.on('user.notifications.14' , function (data) {
      console.log(data);   
  });

  socket.on('disconnect', function() {
    console.log('disconnected');
  });

  socket.emit('subscribe', 'user.notifications.14');
  */
})
