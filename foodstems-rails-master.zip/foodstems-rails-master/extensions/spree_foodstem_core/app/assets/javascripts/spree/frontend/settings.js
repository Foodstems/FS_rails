
Foodstem.Settings = {};

Foodstem.Settings.togglePasswordInputs = function(){
  $('#passwords-inputs,#password-toggle-button').toggleClass('hidden');
  $('#passwords-inputs > input.password').each(function(i, elem){
    elem.value='';
    elem.disabled = !elem.disabled;
  });
};

Foodstem.Settings.cancelChangeEmail = function(path){
  $.get(path, function(data){
    $('input#user_email').val(data.email);
    $('#unconfirmed-email-info').remove();
  });
}
