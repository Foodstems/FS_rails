// Namespace for all classes and methods of Foodstem
Foodstem = {};

var _token = "b082c2ac65ef2ea451646e0f186794accef5345664056111";
function errorAlert(jqxhr, textStatus, error) {
  swal(textStatus.charAt(0).toUpperCase() + textStatus.slice(1), $.parseJSON(jqxhr.responseText).message, 'error')
}

function getDistanceBetween(p1, p2) {
    var R = 6378137; // Earth’s mean radius in meter
      var dLat = rad(p2.lat - p1.lat);
      var dLong = rad(p2.lng - p1.lng);
      var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(rad(p1.lat)) * Math.cos(rad(p2.lat)) *
        Math.sin(dLong / 2) * Math.sin(dLong / 2);
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      var d = R * c;

      var miles = d * 0.00062137
      return Math.round(miles); 
}

  function rad(x) {
    return x * Math.PI / 180;
  }

function getQueryParams(qs) {
    qs = qs.split('+').join(' ');

    var params = {},
        tokens,
        re = /[?&]?([^=]+)=([^&]*)/g;

    while (tokens = re.exec(qs)) {
        params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }

    return params;
}

function ajax_search_products() {
	$("#search-products-map").submit();
	var s = "/search/results?&category="+$("#serach_category :selected").val()+"&distance_to="+$("#distance_to").val()+"&price_from="+$("#price_from").val()+"&price_to="+$("#price_to").val()+"&products_display=true"
    Foodstem.columns[1].load(s)	
}

function _set_google_map(_target, _lat, _lng, _title) {
  var bounds = new google.maps.LatLngBounds();
	var myLatlng = new google.maps.LatLng(_lat,_lng);
  var _userLatLng = new google.maps.LatLng($("#current_user_lat").val(), $("#current_user_lng").val())
  var mapOptions = {
      mapTypeId: 'roadmap',
      zoom: 10,
      maxZoom: 15
  };
	var map = new google.maps.Map(document.getElementById(_target), mapOptions);

  var markers = [
        ['product', _lat,_lng, 'red-dot.png'],
        ['me', $("#current_user_lat").val(),$("#current_user_lng").val(), 'blue-dot.png']
  ];
    var infoWindow = new google.maps.InfoWindow(), marker, i;
    var infoWindowContent = [
        [_title],
        ['My Location']
    ];
// Loop through our array of markers & place each one on the map  
    var marker_image = 'https://maps.google.com/mapfiles/ms/icons/'
    for( i = 0; i < markers.length; i++ ) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        bounds.extend(position);
        marker = new google.maps.Marker({
            position: position,
            map: map,
            title: markers[i][0],
            icon: marker_image + markers[i][3]
        });
        
        // Allow each marker to have an info window    
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infoWindow.setContent(infoWindowContent[i][0]);
                infoWindow.open(map, marker);
            }
        })(marker, i));

        // Automatically center the map fitting all markers on the screen
        map.fitBounds(bounds);
    }

    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
        //this.setZoom(14);
        google.maps.event.removeListener(boundsListener);
    });


}


$(function(){

var xhrQueue = []; 

  $(document).on("click", "#create_new_product_btn", function(e) {
      e.preventDefault();
      $("#new_product").submit();
      $(this).prop("disabled", true)
  });

    // show more bids
    $(document).on("click", ".see-more", function() {
        var ajax_reload = $("#ajax_page_reload").val()
        if (ajax_reload == 1) {
            $("#ajax_page_reload").val("0")
        } else {
            $("#ajax_page_reload").val("1")
        }
    })

  $(document).on("click", ".conversations-delete-conv-button", function(e) {
    e.preventDefault();
    var conversation_id = $(this).attr("conversation-id")
    $.ajax({
      type :"POST",
      data :"conversation_id="+conversation_id,
      url: "/conversations/delete",
      success: function(res) {
        Foodstem.columns[2].load("/conversations")
      },
      error: function(res) {
        Foodstem.columns[2].load("/conversations")
      }
    })
    console.log(conversation_id)
  })

//edit product	
if ($("shipping_service").hasClass("show-parcel-dimensions")) {
  $(".parcel-packaging").show();  
}  

  // search results infinite scroll
  var win = $(window);
   win.scroll(function() {
    // End of the document reached?
    if ($(document).height() - win.height() == win.scrollTop()) {
       $("#show-more-results-search").click();       
    }
  });

	var current_user = $("#spree_current_user_id").val()
	
	$(document).on("click", ".search-item-list", function(){
		$("#search-products").val("")
		$(".search-results").hide()
	})

  
  $(document).on("click", ".feedback-modal-button", function(e) {
    e.preventDefault();
    //ajaxAbort();
  })

	/* checkout page - show product on map */
	$(window).on('shown.bs.modal', function() { 
    $("#ajax_page_reload").val("0");
	});

	$(window).on('hidden.bs.modal', function (e) {
	  $("#ajax_page_reload").val("1");
	})	

  $(document).on("contextmenu", 'a', function(){
    return false;
  })

	$(".notifications-dropdown").on('click', function(){
		$.ajax({
			type:"post",
			url :"/notifications/update_notifications",
			success : function( res ) {
				$("#get-user-notifications").text("");
			}
		})
	})	
  var ajax_search_products_request;
	$("#search-products").attr("aria-expanded", "false")
	$(".search-wrapper").removeClass("open");
	$("#search-products").on("keyup", function(){
		var name = $(this).val();
    //if (name.length >= 3) {
      if(typeof ajax_search_products_request !== 'undefined')
        ajax_search_products_request.abort();  
  		  ajax_search_products_request = 	$.ajax({
  				type : "GET",
  				url : "/search?name=" + name,
  				success : function(res) {
  						$(".search-results").html(res).show();
  						$("#search-products").attr("aria-expanded", "true");
  						$(".search-wrapper").addClass("open");
  				},
  				error : function(err) {
  				}  
  			});

    //}
	})


	// search
    $(document).on("click", "#search-products-map", function() {
            var s = "/search/results?&category="+$("#serach_category :selected").val()+"&distance_to="+$("#distance_to").val()+"&price_from="+$("#price_from").val()+"&price_to="+$("#price_to").val()+"&products_display=true"
            Foodstem.columns[1].load(s)
    })

	$(document).on("click", "#show-more-results-search", function(e) {
		e.preventDefault();
   	// remove show more button
		// it will be added on the next response
		$("#show-more-results-search").remove();
		var url = $(this).attr("data-href");
		$.ajax({
			type : "GET",
			url : url,
			success : function(res) {
				$(".item-box:last").after(res)
			}
		})
	})    


	// hide search dropdown when clicked outside the container
	// https://stackoverflow.com/questions/1403615/use-jquery-to-hide-a-div-when-the-user-clicks-outside-of-it/7385673#7385673
	$(document).mouseup(function (e){
    	var container = $(".search-results");
	    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    	{
        	container.hide();
    	}
	});


  $("a.fancybox").fancybox({
    'transitionIn'  : 'elastic',
    'transitionOut' : 'elastic',
    'speedIn'   : 600, 
    'speedOut'    : 200, 
    'overlayShow' : false
  });


  //calculate distances for products in feed
  $(".product-distance").each(function(k, v){

  	var p1 = {};
    var p2 = {};

    var product_id = $(v).attr('data-product-id')

  	p1.lat = $(v).attr('data-product-lat')
  	p1.lng = $(v).attr('data-product-lng')
  	p2.lat = $(v).attr('data-user-lat')
  	p2.lng = $(v).attr('data-user-lng')
  	
  	var _dist = getDistanceBetween(p1, p2)

  	//$("#product_distance").text(distance+" miles").show()
  	$('.product-distance[data-product-id="'+product_id+'"]').text(_dist+ " miles")
  })



    $("#add_product_in_post_btn").on("click", function(e) {
            e.preventDefault();
            $("#search_products_placeholder").toggle()
      })

      $("#add_product_in_post").on("keyup", function() {

            if ($(this).val().length> 3) {
                  $.ajax({
                        type : "GET",
                        url : "/search/search_product_in_post?name="+$(this).val(),
                        success : function(res) {
                              $(".search-results-add-post").html(res)
                        }
                  })
            }
      })

      $(document).on("click", ".select-product-for-post", function(e){
            e.preventDefault();
            var product_image = $(this).find(".img-circle").attr("src");
            var product_id = $(this).attr("data-product-id");
            var product_title = $(".insert-product-in-post").text();
            $("#foodstem_post_product_id").val(product_id)
            $(".product_image_placeholder_src").attr("src", product_image)
            $("#product_image_placeholder").show();
            $("#close_search_placeholder").show();
            $("input[name='foodstem_post[text]']").text(product_title)
            //fallback
            $("textarea.form-control").text(product_title)
            $("#add_product_in_post").val("");
      })

      $(document).on("click", "#remove_product_for_post", function(e){
            e.preventDefault();

            $(".select-product-for-post").remove();
            $("#product_image_placeholder").hide();
            $("#close_search_placeholder").hide();
            $("#search_products_placeholder").hide();
            $("#foodstem_post_product_id").val("")
            $("textarea.form-control").text("")
      })


      $(document).on("click", ".show-comments-for-post", function(e){
      //$(".show-comments-for-post").on("click", function(e){
        e.preventDefault();
        var post_id = $(this).attr('data-post-id')
        $(".show-comments[data-post-id='"+post_id+"']").toggle()
        if ($(".show-more-comments-icon").hasClass("fa-arrow-down")) {
          $(".show-more-comments-icon").removeClass("fa-arrow-down").addClass("fa-arrow-up")
        }
        if ($(".show-more-comments-icon").hasClass("fa-arrow-up")) {
          $(".show-more-comments-icon").removeClass("fa-arrow-up").addClass("fa-arrow-down")
        }
    })

    $(document).on("click", ".post-comment-in-feed", function(e){
  //$(".post-comment-in-feed").on("click", function(e){
      e.preventDefault();
      var form =  $(this).parents('form:first')
      var parms = form.serialize()
      var action = form.attr('action');
      var post_id = $(this).attr("data-post-id")

      if ( $("#comment_text[data-post-id='"+post_id+"']").val().length < 1) {
          return false;
      }

      $.ajax({
        type: "POST",
        url: action,
        data: parms,
        success: function(res) {
          $("#posts_post_comments[data-parent-id='"+post_id+"']").append(res.content)
          $("#comment_text[data-post-id='"+post_id+"']").val("")
        }
      })
  })
})

