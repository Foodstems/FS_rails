$(document).on('ajax:success', '[data-remote][data-target-column]', function (e, data) {
  
  //when modal is open do not reload the page


  var page_full_width = false;
  var data_full_width = $(this).data('full-width');


  if (!data_full_width) {    
    $("#column-1").removeClass('col-md-12').addClass("col-md-8");
    $("#column-2").show();
  } else {
    $("#column-1").removeClass('col-md-8').addClass("col-md-12");
    $("#column-2").hide();
  } 

  e.stopPropagation();
  var colId = parseInt($(this).data('target-column'));

  if (colId == 3) {
    var modal_title = $(this).data('modal-title');
    var modal_size = $(this).data('modal-size');
    if(modal_title) {
      $('#the-modal h4.modal-title').text(modal_title);
    }
    var the_modal_size="";
    switch(modal_size) {
      case 'large':
        the_modal_size='modal-lg';
        break;
      case 'small':
        the_modal_size='modal-sm';
        break;
    }
    $('#the-modal div.modal-dialog').removeClass().addClass('modal-dialog '+the_modal_size);
	  toggle_the_modal(true);
  } else {
	  toggle_the_modal(false);
  }

  Foodstem.columns[colId].set(this);
  Foodstem.currentColumnNumber = colId;
  Foodstem.Timers.stop(colId);
  Foodstem.Columns.updateHistory();

  $('#column-'+colId).html(data);

  //var $links = $('#column-'+colId + ' a[data-remote="true"]');
  var $links = $('a[data-remote="true"]');
  var $forms = $('#column-'+colId).find('form[data-remote="true"]');

  $forms.on('submit', function() {
    // If form under the validation (http://jqueryvalidation.org/) and
    // form is invalid, then no showing spinner
    if ($(this).valid && !$(this).valid()) {
      return;
    }
    $('#column-' + $(this).data('target-column')).append(Foodstem.WAITING_SPINNER_HTML);
  });

  $links.on('click', function(event) {

    if (event.ctrlKey) {
        event.preventDefault();
        return false;
    }

    if(event.button == 1 || event.button == 2)
    {
      event.preventDefault();
      return false;
    }

    $('#column-' + $(this).data('target-column')).append(Foodstem.WAITING_SPINNER_HTML);

  });

  $links.on('contextmenu', function() {
    return false;
  });

});

function toggle_the_modal(toggle) {
if(toggle) {
    $("#column-3").show();
    $('#the-modal').modal('show'); //$('#the-modal').modal('toggle'); works as well
    } else {
    $("#column-3").hide();
    $('#the-modal').modal('hide');
    }
}

