function FS_Notifications () {}

FS_Notifications.prototype.user_id = 14
FS_Notifications.prototype.socket = ""

FS_Notifications.prototype.init = function(socket) {
	this.socket = socket
	this.socket.emit('subscribe', 'user.notifications.' + this.user_id);
	this.get_notification();
}

FS_Notifications.prototype.get_notification = function () {

  socket.on('user.notifications.' + this.user_id , function (data) {
      console.log(data);   
  });
}