module Spree
  class HomeController < Spree::StoreController
    #layout 'greetings_layout'
    layout 'login_layout'
    def index
      unless try_spree_current_user.nil?
        redirect_to foodstem_path
      end
    end
  end
end
