class Spree::Foodstem::NotificationsController < Spree::StoreController

  helper_method :notification_opts

  NOTIFICATIONS = [
    'new',
    'new_message',
    'new_feedback',
    'new_awaiting_feedback',
    'new_ticket',
    'new_ticket_comment',
    'new_incoming_ticket_comment',
    'new_order',
    'new_follower'
  ]

  def index
    @notifications = spree_current_user.all_notifications
    if params[:before_that].present?
      @notifications = @notifications.where('updated_at < ?', Time.my_strptime(params[:before_that])).order(updated_at: :desc).limit(Rails.application.config.show_more_item_count)
      render @notifications
    else
      @notifications = @notifications.order(updated_at: :desc).limit(Rails.application.config.show_more_item_count)
    end
    @notifications.update_all(deleted_at: DateTime.now)
  end

  def notification_opts(notification)
    { notification_image_url: '', title: 'Title', content: 'Content', path: :notifications_path, url_helper_opts: {} }
  end

  def update_notifications
    @notifications = spree_current_user.all_notifications
    @notifications.update_all(deleted_at: DateTime.now)
    render json:{
      'new_message' => 'Notifications updated'
    }
  end

  def load
    #new_notifications = spree_current_user.new_notifications
    #new_notifications = new_notifications.where('created_at > ?', Time.my_strptime(params[:after_that])) if params[:after_that].present?
    @notifications = Spree::Foodstem::Notification.where(user_id:spree_current_user.id).order(created_at: :desc).limit(10)
    
    @new_notifications =  @notifications.where("deleted_at IS  NULL").size
    render json:{
      'new_notifications' =>  @notifications.where("deleted_at IS  NULL").size,
      'content' => render_to_string(:template => "spree/foodstem/notifications/load")

    }
    #if new_notifications.empty?
     # render json: {}
  #  else
     # notifications = {}
     # NOTIFICATIONS.each do |x|
     #   clazz = Spree::Helpers::NotifyHelper.notify_class(x)
      #  count = spree_current_user.send("#{x}_notifications").count
      #  notifications[clazz] = count if count > 0
     # end

      #return render :index
      #render json: {
      #  lastTime: new_notifications.order(created_at: :desc).take.created_at.my_strftime,
      #  notifications: notifications
      #}
  
  end

end
