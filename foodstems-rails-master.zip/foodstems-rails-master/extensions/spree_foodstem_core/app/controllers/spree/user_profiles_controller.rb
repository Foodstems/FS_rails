class Spree::UserProfilesController < Spree::StoreController
  before_action :check_user
  before_action :set_param_code
  before_action :check_step1, only: [:quiz_step1, :quiz_step1_submit]
  before_action :check_step2, only: [:quiz_step2, :quiz_step2_submit]
  require "base64"
  def quiz_step1
    if spree_user_signed_in? && !spree_current_user.location.nil?
        return redirect_to('/app')
    end

    render :layout => 'greetings_layout'
    if params[:code].present?
      dec_code =  Base64.decode64(params[:code])
  
      @profile    = Spree::UserProfile.where('email = ?', dec_code).first
    else
      @profile = Spree::UserProfile.last
    end
    @first_name = !params[:user_profile].nil? ? params[:user_profile][:first_name] : ""
    @last_name  = !params[:user_profile].nil? ? params[:user_profile][:last_name] : ""

  end

  def edit
  end

  def quiz_step1_submit
   # abort params[:foodstem_merchant][:location].inspect
    @profile = Spree::UserProfile.where("email = ? ", params[:foodstem_merchant][:email]).first
    @first_name = !params[:user_profile].nil? ? params[:user_profile][:first_name] : ""
    @last_name = !params[:user_profile].nil? ? params[:user_profile][:last_name] : ""

    if params["user_profile"]["agreement_sign"].to_i == 0 
      return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "You must accept user agreement!" }
    end    

    if params[:user_profile][:first_name].empty?
      return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "Firstname must not be empty!" }
    end

    #if params[:user_profile][:last_name].empty?
     # return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "Last name must not be empty!" }
    #end

    if params[:user_profile][:user][:location].empty?
       return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "Location must not be empty!" }
    end
    if params[:user_profile][:user][:lat].empty?
       return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "Location must not be empty!" }
    end
    par = params.require(:user_profile).permit(:first_name, :last_name, :agreement_sign)
    #abort merchant_params.inspect
    
    @profile.update par
    set_user_location

    @profile.social_confirm = "";
    if @profile.save
      #redirect_to quiz_step2_path
      #create roles [Producer and Consumer]
      fill_social_roles [1,2]
  
      #create merchant
      #create merchant
      require "stripe"
      Stripe.api_key = Rails.application.config.stripe_secret_key
      stripe = Stripe::Account.create(
        :type       => 'custom',
        :country    => 'US',
        :email      => @profile.user.email,
        :payout_schedule => {
          :interval => "manual"
        }
      )
      merchant = Spree::Foodstem::Merchant.new
      merchant.user_id = @profile.user.id
      merchant.stripe_account_id = stripe.id
      merchant.destination = "bank"
      merchant.first_name = @profile.first_name
      merchant.last_name = @profile.last_name
      merchant.date_of_birth = "1926-12-13"
      merchant.email = @profile.user.email
      merchant.save!

      redirect_to foodstem_path and return
    else

        return redirect_to "/registration?code=#{@param_code}",  :flash => { :error => "Error while registering" }
      render :quiz_step1, layout: 'greetings_layout'
    end
  end

  def update_avatar_on_register
    profile_params = params.permit(:avatar)
    image = Spree::Image.new(attachment: profile_params[:avatar])
    image.viewable = @profile
    image.save!
    profile_params[:avatar_id] = image.id
    profile_params.except! :avatar
    profile =  spree_current_user.user_profile
    profile.update! profile_params

    return render json:{
          profile: profile,
    }
  end

  def quiz_step2
    render :layout => 'greetings_layout'
  end

  def quiz_step2_submit
    #begin
    fill_social_roles params.require(:user_profile).require(:social_roles).permit!.keys
    if @profile.save
      redirect_to @profile.is_producer? ? quiz_step3_path : foodstem_path
    else
      render :quiz_step2, layout: 'greetings_layout'
    end
    #rescue
    #  redirect_to quiz_step2_path and return
    #end

  end

  def quiz_step3_submin
    abort params.inspect
  end


  protected

  def set_param_code
    @param_code = ""
    if params[:code].present?
      @param_code = params[:code]
    end
  end  

  def check_user
    if spree_current_user.nil?
      redirect_unauthorized_access
    end
  end

  def check_step1
    @profile = spree_current_user.user_profile    
    if @profile.nil?
      #check if this user logs from facebook
      require 'base64'
      if params[:code].present?
        dec_code =  Base64.decode64(params[:code])
      end
      @profile = Spree::UserProfile.where('email = ?', dec_code).first
      #@profile = Spree::UserProfile.where("social_confirm = 'facebook'").first
      if @profile.nil?
        @profile ||= Spree::UserProfile.new
      end
      @profile.user_id = spree_current_user.id
      @profile.save
    else
      authorize! :update, @profile
    end
  end

  def check_step2
    @profile = spree_current_user.user_profile
    if @profile.nil? or not @profile.agreement_sign or @profile.user.location.empty?
      redirect_to quiz_step1_path and return
    end
    authorize! :update, @profile
    unless @profile.social_roles.empty?
      redirect_to foodstem_path and return
    end
  end

  def fill_social_roles keys
    roles = Spree::SocialRole.where id: keys
    @profile.social_roles = roles
  end

  def set_user_location
    p = params.require(:user_profile).require(:user).permit :lat, :lng, :location
    @profile.user.update p

  end

  def merchant_params
    params.require(:foodstem_merchant).permit(:first_name, :last_name, :email,  :date_of_birth,                                            :location, :lat, :lng, :street_address, :locality, :region, :postal_code, :account_number, :routing_number)
  end
  def create_braintree_merchant!(params, destination)

    Braintree::Configuration.environment = :sandbox
    Braintree::Configuration.logger = Logger.new('log/braintree.log')
    Braintree::Configuration.merchant_id = 'xfj5qkg6bfz4ykpp'
    Braintree::Configuration.public_key = '5bg7hw5y2rwhfgqw'
    Braintree::Configuration.private_key = '69a6b9bfa68e86c1575c803dc06dc152'

    #built_date = Date.new(params['date_of_birth(1i)'].to_i, params['date_of_birth(2i)'].to_i, params['date_of_birth(3i)'].to_i)
    built_date=params[:date_of_birth]
    Braintree::MerchantAccount.create(
        individual: {
            first_name: params[:first_name],
            last_name: params[:last_name],
            date_of_birth: built_date,
            email: params[:email],
            address: {
                street_address: params[:street_address],
                locality: params[:locality],
                region: params[:region],
                postal_code: params[:postal_code]
            }
        },
        funding: {
            destination: destination,
            account_number: params[:account_number],
            routing_number: params[:routing_number]
        },
        tos_accepted: true,
        master_merchant_account_id: "contentmutualinc"
    )

  end
end
