module Spree
  class FoodstemController < Spree::StoreController
    before_action :authenticate_spree_user!
    before_action :check_quiz
    
    require "base64"
    #layout 'foodstem_layout'
    layout 'fs_layout'
    def index
      @count_follows = spree_current_user.follows.size
      @activities = PublicActivity::Activity
        .joins('JOIN foodstem_posts ON foodstem_activities.trackable_id = foodstem_posts.id')
        .where('foodstem_posts.deleted = FALSE AND foodstem_activities.trackable_type = ? AND owner_type = ? AND (owner_id IN (?) OR owner_id = ?) AND key LIKE \'%create\'', Spree::Foodstem::Post.name, Spree::User.name, spree_current_user.follows_ids, spree_current_user.id)
        .order('foodstem_activities.created_at DESC')
        .limit(Rails.application.config.show_more_item_count)

      @column = params[:column].to_i if params[:column].present?
      @url = url
      @address = Address.new
      @post = Spree::Foodstem::Post.new
      @homepage = true
      @profile_photo = Spree::Foodstem::ProfileImage.new
      @col2width = 3
      @col1width = 8

      @suggested_followers_closest    = false
      @suggested_followers_activity   = false
      @facebook_followers             = false

      @profile_lat = spree_current_user.lat.nil? ? 0 : spree_current_user.lat
      @profile_lng = spree_current_user.lng.nil? ? 0 : spree_current_user.lng 

      if spree_current_user.follows.size < 1
        
        require 'koala'
        friends = []
        unless spree_current_user.user_profile.access_token.nil?
          #if user has changed fb password, token is invalid. must get new token?
          @graph = Koala::Facebook::API.new(spree_current_user.user_profile.access_token)
          begin 
            friends =  @graph.get_connection("me", "friends")
            unless friends.empty?
              f = friends.map{|x| x['id']}.map(&:inspect).join(', ')
              fb_sql = "select sp.id as id from spree_users sp join spree_user_profiles sup on sup.user_id = sp.id where sup.social_uid IN (#{f.tr('"', "'")})"
              @facebook_followers = ActiveRecord::Base.connection.execute(fb_sql) 
          end
          rescue => ex
              friends = []
              redirect_to "/users/auth/facebook" and return
          end
        end

        sql = "SELECT t2.* FROM (
        SELECT COUNT(distinct fa.id) AS number_of_actvities, COUNT(distinct so.id) as number_of_orders, 
        3959 * ACOS( COS( RADIANS(#{@profile_lat}) ) * COS( RADIANS(lat) ) * COS( RADIANS(lng) - RADIANS(#{@profile_lng}) ) + SIN( RADIANS(#{@profile_lat}) ) * SIN( RADIANS(lat))) AS distance ,
        sp.id, sp.email, sp.lat, sp.lng
        FROM spree_users sp
        left JOIN foodstem_activities fa ON fa.owner_id = sp.id
        LEFT JOIN spree_orders so ON sp.id = so.user_id
        WHERE sp.id != '#{spree_current_user.id}' "
        unless friends.empty?
          sql+= "and sp.id not in (select sp.id as id from spree_users sp join spree_user_profiles sup on sup.user_id = sp.id where sup.social_uid IN (#{f.tr('"', "'")}))" 
        end
        
        sql+="GROUP BY sp.id) AS t2
        where distance > 0
        ORDER BY number_of_orders desc, number_of_actvities desc, distance  asc
        LIMIT 3"
        # ORDER BY number_of_orders desc, number_of_actvities desc, distance  asc
        @suggested_followers_closest    = ActiveRecord::Base.connection.execute(sql)

      end

    end

    def user_products
         @products = spree_current_user.products.order('id DESC').page(params[:page]).per(Rails.application.config.user_products_per_page)
         @products_history = spree_current_user.products.order('id DESC').page(params[:page]).per(Rails.application.config.user_products_per_page)
         #render :'spree/products/index'
        @col2width = 0
        @col1width = 12
    end

 
    def user_orders
      @col2width = 0
      @col1width = 12
    end

    private

    def get_facebook_friends

      require 'koala'
      fb_friends = []

      @graph = Koala::Facebook::API.new(spree_current_user.user_profile.access_token)
      friends =  @graph.get_connection("me", "friends")
      unless friends.empty?
        f = friends.map{|x| x['id']}.map(&:inspect).join(', ')
        sql = "select * from spree_users sp join spree_user_profiles sup on sup.user_id = sp.id where sup.social_uid IN (#{f.tr('"', "'")})"
        fb_friends = ActiveRecord::Base.connection.execute(sql)  
      end
    end

    def column
      params[:column].present? ? params[:column].to_i : nil
    end

    def url
      ret = ''
      excluded = [ 'controller', 'action' ]
      for i in 1..4
        break if params["l#{i}"].blank?
        ret += '/' + params["l#{i}"]
        excluded << "l#{i}"
      end
      query = ''
      params.each do |k, v|
        query += '&' if query != ''
        query += "#{k}=#{v}" unless excluded.include?(k)
      end
      ret + '?' + query
    end

    def check_quiz
      
      user = spree_current_user
      email_crypt = Base64.encode64(user.email)
      profile = user.user_profile
      if profile.nil? or not profile.agreement_sign or profile.user.location.nil?
        #redirect_to quiz_step1_path and return
        redirect_to "/registration?code=#{email_crypt}"
      end
    
    end
  end
end