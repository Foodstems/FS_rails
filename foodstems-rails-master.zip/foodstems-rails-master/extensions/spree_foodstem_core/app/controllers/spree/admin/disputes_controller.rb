class Spree::Admin::DisputesController < Spree::Admin::BaseController
  skip_before_action :verify_authenticity_token
  def index
    @disputes = Spree::Foodstem::DisputeOrder.where('accepted = ?', "new")
  end

  def show
   @dispute = Spree::Foodstem::DisputeOrder.find(params[:id])

  end

  def create
    
    begin

      dispute = Spree::Foodstem::DisputeOrder.find(params[:id])

      if !params[:refund].nil?
        #refund the transactions
        dispute.order.payments.each do |payment|
          payment.is_refunded = 1
          payment.save
          
          require "stripe"
          Stripe.api_key = Rails.application.config.stripe_secret_key

          re = Stripe::Refund.create(
            charge: payment.response_code
          )

          #save the transaction
          #this is money in  for buyer
          transaction_buyer                       = Spree::Foodstem::Transaction.new
          transaction_buyer.user_id               = dispute.order.user.id
          transaction_buyer.amount                = payment.amount.to_f*100 #in cents
          transaction_buyer.transaction_type      = "refund"
          transaction_buyer.direction             = "in"
          transaction_buyer.description           = dispute.order.product.description
          transaction_buyer.order_number          = dispute.order.number
          transaction_buyer.save

          #update seller balance
          user          = payment.order.product.user
          balance       = user.balance
          user.balance  = balance - payment.amount.to_f*100
          user.save
        end

        dispute.accepted = 'yes'
        dispute.save
        flash[:success] = "Dispute was accepted"
      end

      if !params[:decline].nil?
        dispute.order.payments.each do |payment|
          payment.is_disputed = 0
          payment.save
        end
        dispute.accepted = 'no'
        dispute.save
        flash[:success] = "Dispute was declined"
      end

    rescue => ex
      err_code = 12.times.map { [*'0'..'9', *'a'..'z'].sample }.join
      flash[:error] =  "Error while updating dispute. Code ##{err_code}" 
      FsLog.debug [
                "message" => "CODE:#{err_code}: " + ex.message, 
                "line" => __LINE__, 
                "file" => __FILE__,
                "method" => __method__
            ].to_s
    end

    redirect_to action: "index"
    

  end

  #index.response do |wants|
  #  wants.html { redirect_to index_admin_disputes_url( @fancy_thing ) }
 # end

  # redirect to the edit action after create
  #create.response do |wants|
  #  wants.html { redirect_to edit_admin_disputes_url( @fancy_thing ) }
  #end

  # redirect to the edit action after update
  ##update.response do |wants|
  #  wants.html { redirect_to edit_admin_disputes_url( @fancy_thing ) }
  #end

end