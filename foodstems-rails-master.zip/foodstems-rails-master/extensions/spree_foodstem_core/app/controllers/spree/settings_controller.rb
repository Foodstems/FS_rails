class Spree::SettingsController < Spree::StoreController
  layout 'settings'
  helper Spree::Helpers::LinkToCol

  def show
  end
end
