class Spree::Settings::PaymentsSettingsController < Spree::StoreController

  layout 'settings'

  def show
    redirect_to :cards_payments_settings
  end

  def update
    
  end

  def cards
    if try_spree_current_user && try_spree_current_user.respond_to?(:payment_sources)
      @payment_sources = try_spree_current_user.payment_sources
    end
  end

  def seller_account
    @merchant = spree_current_user.merchant || spree_current_user.build
  end

end