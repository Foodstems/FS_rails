class Spree::Settings::GeneralSettingsController < Spree::StoreController

  layout 'settings'

  def show
  end

  def update
    @user = spree_current_user
    successfully_updated = @user.update_with_password general_settings

    if successfully_updated
      flash.now[:notice] = 'General settings have been updated.'
      sign_in @user, :bypass => true
    end
    render :show
  end

  def cancel_change_email
    spree_current_user.cancel_change_email!
    render status: 200, json: {email: spree_current_user.email}
  end

  private

    def general_settings
      general_params = params.required(:user).permit(
          :current_password, :password, :password_confirmation, :email,
          user_profile_attributes: [:id, :first_name, :last_name]
      )
      general_params
    end
end
