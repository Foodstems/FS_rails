class Spree::Settings::PrivacySettingsController < Spree::StoreController

  def edit

  end

  def update

  end

end