Spree::StoreController.class_eval do

  helper Spree::Helpers::LinkToCol
  helper Spree::Helpers::RatingHelper
  helper Spree::Helpers::StringHelper
  helper Spree::Helpers::MyErrorHelper
  helper Spree::Helpers::NotifyHelper
  helper_method :my_path_div

  include Spree::Helpers::NotifyHelper
  include PublicActivity::StoreController

  before_action :fix_temp_post
  before_action :set_user_balance
  before_filter :set_cache_buster

  def set_user_balance
    @balance = 1
    @balance =  (spree_current_user.balance.to_f / 100) unless spree_current_user.nil?
  end

  def set_cache_buster
    #response.headers["Cache-Control"] = "no-cache, no-store, max-age=0, must-revalidate"
    #response.headers["Pragma"] = "no-cache"
    #response.headers["Expires"] = "Fri, 01 Jan 1990 00:00:00 GMT"
  end

  def my_path_div
    '<i class="fa fa-angle-right my-path-div"></i>'.html_safe
  end

  def fix_temp_post
      data = {:empty=>true}

      $redis.publish('messages.create', data.to_json)    
      $redis.publish('messages.new', data.to_json)
      $redis.publish('conversation.create', data.to_json)   
      $redis.publish('bids.last_bid', data.to_json) 

      @_post = Spree::Foodstem::Post.where("text = ?", session.id)
      if @_post.count > 0 
        @_post.each do |p|
          p.deleted = true
          p.save
        end
      end
  end


end
