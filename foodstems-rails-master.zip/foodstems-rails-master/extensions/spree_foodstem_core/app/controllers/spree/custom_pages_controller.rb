module Spree
  class CustomPagesController < Spree::StoreController

    def report_problem

    end
  end
end
