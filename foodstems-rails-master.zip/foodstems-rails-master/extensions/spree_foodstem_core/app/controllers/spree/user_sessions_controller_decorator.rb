Spree::UserSessionsController.class_eval do
  alias_method :old_create, :create
  def create

    #@user = build_resource(spree_user_params)
    @email = params.require(:spree_user).permit(:email)[:email]
    
    authenticate_spree_user!
    
    if spree_user_signed_in?
    	redirect_to "/app" and return
    else
    	set_flash_message(:error, :invalid)  
    end
  end
end