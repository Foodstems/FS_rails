Spree::Admin::ImagesController.class_eval do

  def destroy
    if  @object.destroy
      flash[:success] = flash_message_for(@object, :successfully_removed)
      render status: 204, json: @object.to_json
    else
      render status: 403, json: @object.to_json
    end
  end

end