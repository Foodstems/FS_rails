Spree::UserRegistrationsController.class_eval do
  #layout 'login_layout'
  before_action :set_profile_values
  skip_before_action :verify_authenticity_token

  def new
    if spree_user_signed_in?
        return redirect_to('/app')
    end
    @profile ||= Spree::UserProfile.new
    render 'new_user' and return
  end
  def create
    @email_error = false 
    @password_error = false
    @password1_error = false
    @firstname_error = false
    @lastname_error = false
    @location_error = false
    @avatar_error = false
    

    begin 

    @user = build_resource(spree_user_params)
  
    #dont allow location with unknown params
    if params[:foodstem_merchant][:location].empty?
      @location_error = true
      set_flash_message(:alert, :register_invalid_location)
      return render 'new_user'    
    else
      unless params[:foodstem_merchant][:location].match(/undefined/).nil?
        @location_error = true
        set_flash_message(:alert, :register_invalid_location)
        return render 'new_user'    
    end

    end

    if params["user_profile"]["agreement_sign"].to_i == 0 
      set_flash_message(:alert, :register_agreement)      
      return render 'new_user'      
    end   

    if params[:user_profile][:first_name].empty?
      @firstname_error = true
      set_flash_message(:alert, :register_first_name)      
      return render 'new_user'
    end

    if params["choosenImage"].empty?
      @avatar_error = true
      set_flash_message(:alert, :register_image)
      return render 'new_user' 
    end 

    if params[:user_profile][:user][:location].empty?
      @location_error = true
      
      set_flash_message(:alert, :register_location)
      return render 'new_user'        
    end
    if params[:user_profile][:user][:lat].empty?
      set_flash_message(:alert, :register_location)
      return render 'new_user'
    end

   

    @user.skip_confirmation!
    if @user.save

      #create profile
      @p = Spree::UserProfile.new
      profile_params = params.require(:user_profile).permit(:first_name, :agreement_sign)
      @p.first_name     = params[:user_profile][:first_name]
      @p.last_name      = params[:user_profile][:last_name]
      @p.agreement_sign = true
      @p.user_id = @user.id
      @p.save!

      
      location_params = params.require(:user_profile).require(:user).permit :lat, :lng, :location
      @p.user.update location_params

      roles = Spree::SocialRole.where id: [1, 2]
      @p.social_roles = roles
      @p.save!

      #update profile avatar
      unless params[:avatar].nil?
        set_profile_avatar @p
      end

      #create merchant
      require "stripe"
      Stripe.api_key = Rails.application.config.stripe_secret_key
      stripe = Stripe::Account.create(
        :type     => 'custom',
        :country  => 'US',
        :email    => @user.email,
        :payout_schedule => {
          :interval => "manual"
        }
      )
      merchant = Spree::Foodstem::Merchant.new
      merchant.user_id = @user.id
      merchant.stripe_account_id = stripe.id
      merchant.destination = "bank"
      merchant.first_name = @p.first_name
      merchant.last_name = @p.last_name
      merchant.date_of_birth = "1926-12-13"
      merchant.email = @user.email
      merchant.account_number = "123543"
      merchant.routing_number = "011600033"
      merchant.location = ""
      merchant.lat = ""
      merchant.lng = ""
      merchant.street_address = ""
      merchant.locality = ""
      merchant.region = ""
      merchant.postal_code = ""
      merchant.save!
 
      session[:spree_user_signup] = true
      associate_user
      sign_in @user
      respond_with resource, location: "/app"
    else
      #@user.delete
      #abort resource.errors.inspect
      resource.errors.each do |e|
        set_flash_message(:alert, e)
      end
      clean_up_passwords(resource)
      render 'new_user'
    end

    rescue => ex
      #@user.delete
      set_flash_message(:alert, ex.message)
        err_code = 12.times.map { [*'0'..'9', *'a'..'z'].sample }.join
        FsLog.debug [
          "message" => "CODE:#{err_code}: " + ex.message, 
          "line" => __LINE__, 
          "file" => __FILE__,
          "method" => __method__
        ].to_s
      logger.error ex.message
      return render 'new_user'
    end
  end

  protected
  def set_profile_values
    @profile_first_name = params["user_profile"].nil? ? "" : params["user_profile"]["first_name"] 
    @profile_last_name  = params["user_profile"].nil? ? "" : params["user_profile"]["last_name"] 
    @profile_email      = params["spree_user"].nil? ? "" : params["spree_user"]["email"] 
    @choosenImage       = params["choosenImage"]
    @profile_address    = params["user_profile"].nil? ? "" : params["user_profile"]["user"]["location"]
    @lat                = params["user_profile"].nil? ? "" : params["user_profile"]["user"]["lat"]
    @lng                = params["user_profile"].nil? ? "" : params["user_profile"]["user"]["lng"]
    @foodstem_location  = params["foodstem_merchant"].nil? ? "" : params["foodstem_merchant"]["location"]
    @foodstem_merchant_locality = params["foodstem_merchant"].nil? ? "" : params["foodstem_merchant"]["locality"]
    @foodstem_merchant_region = params["foodstem_merchant"].nil? ? "" : params["foodstem_merchant"]["region"]
    @foodstem_merchant_postal_code = params["foodstem_merchant"].nil? ? "" : params["foodstem_merchant"]["postal_code"]
  end
 
 def merchant_params
    params.require(:foodstem_merchant).permit(:first_name, :email,  :date_of_birth,                                            :location, :lat, :lng, :street_address, :locality, :region, :postal_code, :account_number, :routing_number)
 end

  def create_braintree_merchant!(params, destination)

    #built_date = Date.new(params['date_of_birth(1i)'].to_i, params['date_of_birth(2i)'].to_i, params['date_of_birth(3i)'].to_i)
    built_date=params[:date_of_birth]
    Braintree::MerchantAccount.create(
        individual: {
            first_name: params[:first_name],
            last_name: params[:last_name],
            date_of_birth: built_date,
            email: params[:email],
            address: {
                street_address: params[:street_address],
                locality: params[:locality],
                region: params[:region],
                postal_code: params[:postal_code]
            }
        },
        funding: {
            destination: destination,
            account_number: params[:account_number],
            routing_number: params[:routing_number]
        },
        tos_accepted: true,
        master_merchant_account_id: "contentmutualinc"
    )

  end

   def set_profile_avatar (profile)
    profile_params = params.permit(:avatar)
    image = Spree::Image.new(attachment: profile_params[:avatar])
    image.viewable = @profile
    image.save!
    profile_params[:avatar_id] = image.id
    profile_params.except! :avatar
    profile.update! profile_params
    return true
  end
end
