Spree::UserPasswordsController.class_eval do
	def new
	end
	def edit
		@token = params[:reset_password_token]
	end
end