class String
  def my_i?
     /\A[-+]?\d+\z/ === self
  end
end
