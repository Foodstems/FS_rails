class Time
  def Time.my_strptime(str)
    Time.strptime(str, '%Y-%m-%d %H:%M:%S.%N %Z')
  end
end
