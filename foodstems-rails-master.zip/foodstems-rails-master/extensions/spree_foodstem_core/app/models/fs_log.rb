class FsLog
  def self.debug(message=nil)
    @fs_log ||= Logger.new("#{Rails.root}/log/foodstems.log")
    @fs_log.debug(message) unless message.nil?
  end
end