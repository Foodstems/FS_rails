class Object
  def my_true?
    self.present? && (self === true || self === 'true' || self == 1 || self == '1')
  end
end
