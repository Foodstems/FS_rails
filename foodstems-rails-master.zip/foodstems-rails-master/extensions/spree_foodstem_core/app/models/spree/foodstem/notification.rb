class Spree::Foodstem::Notification < ActiveRecord::Base
  self.table_name = 'foodstem_notifications'

  belongs_to :user, class_name: Spree::user_class.name
  belongs_to :source, polymorphic: true

end
