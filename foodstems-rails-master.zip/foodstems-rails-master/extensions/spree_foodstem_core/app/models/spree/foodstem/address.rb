class Spree::Foodstem::Address < ActiveRecord::Base
  self.table_name = 'foodstem_addresses'

  belongs_to :user, class_name: Spree.user_class.name
  belongs_to :address, class_name: Spree::Address.name

end
