class Spree::SocialRole < ActiveRecord::Base
  has_and_belongs_to_many :user_profiles, 
                          join_table: 'spree_social_roles_spree_user_profiles', 
                          class_name: 'Spree::UserProfile',
                          association_foreign_key: :spree_user_profile_id,
                          foreign_key: :spree_social_role_id
end
