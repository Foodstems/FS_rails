class Spree::UserProfile < ActiveRecord::Base
  extend FriendlyId
  attr_accessor :test

  belongs_to :user, class_name: Spree.user_class
  has_and_belongs_to_many :social_roles,
                          join_table: 'spree_social_roles_spree_user_profiles',
                          class_name: 'Spree::SocialRole',
                          association_foreign_key: :spree_social_role_id,
                          foreign_key: :spree_user_profile_id
  has_many :photos, class_name: 'Spree::Foodstem::ProfileImage'
  before_validation :capitalize_names
  # before_save :evaluate_slug
  validates :slug, format: {
                             with: /\A[A-z0-9\-\_]+\Z/,
                             message: "can contains english letters, numbers, '-' and '_'"
                         }

  validates_inclusion_of :agreement_sign, in: [true], message: 'is not accepted'
  validates_presence_of :first_name
  #validates_presence_of :last_name
  friendly_id :slug_candidates, use: [:slugged, :finders]
 
  def slug_candidates
    [
      first_name.downcase,
      [first_name.downcase, last_name.downcase],
      [user_id, first_name.downcase, last_name.downcase]
    ]
  end

  def should_generate_new_friendly_id?
    new_record? ? true : false
  end

  MERCHANT = 1
  CUSTOMER = 2

  def avatar_url
    if self.avatar_id.nil?
      'noimage/small.png'
    else
      self.avatar.attachment.url(:product)
    end
  end

  def mini_avatar_url
    if self.avatar_id.nil?
      ActionController::Base.helpers.image_url('noimage/small.png')
    else
      self.avatar.attachment.url(:mini)
    end
  end

  def small_avatar_url
    if self.avatar_id.nil?
      'noimage/small.png'
    else
      self.avatar.attachment.url(:small)
    end
  end

  def is_producer?
    social_roles.exists?(name: 'Producer')
  end

  protected

  def capitalize_names
    self.first_name = self.first_name.mb_chars.capitalize.to_s
    self.last_name = self.last_name.mb_chars.capitalize.to_s
  end


end
