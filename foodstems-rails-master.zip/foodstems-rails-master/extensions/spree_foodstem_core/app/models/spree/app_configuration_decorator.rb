Spree::AppConfiguration.class_eval do
    preference :commision, :integer
end