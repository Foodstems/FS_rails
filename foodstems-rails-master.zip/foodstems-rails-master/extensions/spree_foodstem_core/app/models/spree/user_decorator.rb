# Perhaps, we need to stop use class 'Spree::User' and write custom class, that will contains logic of all user class decorators.
Spree.user_class.class_eval do
  acts_as_geolocated
  has_many :bank_accounts, class_name: Spree::Foodstem::BankAccount.model_name
  has_one :user_profile, dependent: :destroy
  accepts_nested_attributes_for :user_profile
  has_one :merchant, class_name: Spree::Foodstem::Merchant.model_name
  has_many :orders, class_name: Spree::Foodstem::Order.model_name
  has_many :product_addresses, class_name: Spree::ProductAddress.model_name
  validates :unconfirmed_email, :allow_nil => true, :email => true, uniqueness: true
  validate :unconfirmed_email_should_be_available
  has_many :addresses, class_name: Spree::Foodstem::Address.model_name
  
  has_many :transactions, class_name: Spree::Foodstem::Transaction.model_name
  has_many :transactions_in, -> {where(direction: "in").where.not(transaction_type: "withdraw").order(created_at: :desc)}, class_name: Spree::Foodstem::Transaction.model_name
  has_many :transactions_out, -> {where(direction: "out").order(created_at: :desc)}, class_name: Spree::Foodstem::Transaction.model_name
  has_many :withdraws, -> {where(transaction_type: "withdraw")}, class_name: Spree::Foodstem::Transaction.model_name

  def unconfirmed_email_should_be_available
    unless Spree.user_class.where(email: unconfirmed_email).empty?
      errors.add(:unconfirmed_email, 'has already been taken')
    end
  end

  def cancel_change_email!
    self.confirmation_token = nil
    self.unconfirmed_email = nil
    self.save!
  end

  has_many :new_notifications, -> { where(deleted_at: nil).order(created_at: :desc) }, class_name: Spree::Foodstem::Notification.name
  has_many :all_notifications, -> { order(created_at: :desc) }, class_name: Spree::Foodstem::Notification.name

  has_settings do |s|
    s.key :privacy
    s.key :general
  end

  alias_method :apply_omniauth_orig, :apply_omniauth
  alias_method :old_confirm!, :confirm!

  def apply_omniauth(omniauth)
    
    profile = Spree::UserProfile::where('social_uid = ?', omniauth.uid).first
    #image = "http://graph.facebook.com/#{omniauth.uid}/picture?type=large"
    i = URI.parse("https://graph.facebook.com/#{omniauth.uid}/picture?type=large")
    full_name =  omniauth[:info][:name].split(' ',2)
    
    if profile.nil?

      #check if this email is alredy registerd via normal signup
      fb_user = Spree::User.where('email = ?', omniauth['info']['email'])
      #abort fb_user.count.inspect
      if fb_user.count > 0
        #set_flash_message(:alert, :register_location)
        return false
      end

      apply_omniauth_orig omniauth
      if omniauth[:provider] == 'linkedin'
        self.email = omniauth['info']['email'] if email.blank?
      end
      profile ||= Spree::UserProfile.new user_id: self.id

      profile.first_name      ||= full_name[0]
      profile.last_name       ||= full_name[1]
      profile.agreement_sign  = true
      profile.social_confirm  = "facebook"
      profile.social_uid      = omniauth.uid
      profile.email           = omniauth['info']['email']
      profile.access_token    = omniauth['credentials']['token']

      if  !omniauth['extra']['raw_info'].birthday.nil?
        b_day = omniauth['extra']['raw_info'].birthday.split("/")
        profile.dob_m = b_day[0]
        profile.dob_d = b_day[1]
        profile.dob_y = b_day[2]
      end

      profile.save!
      i = URI.parse("https://graph.facebook.com/#{omniauth.uid}/picture?type=large")
      image = Spree::Image.new(attachment: i)
      image.viewable = profile
      image.attachment_file_name
      image.save!  
      profile.avatar_id = image.id
      profile.save
      self.skip_confirmation!
    else
      #update access token
      profile.access_token    = omniauth['credentials']['token']
      profile.save
    end
  end

  def confirm!
    old_confirm!
    # This is very bad practice, but unfortunately it's needed to change email for login,
    # because class 'User' designed by Spree uses terrible method 'Spree::User.set_login' before validation.
    self.login = self.email
    save!
  end

  def stripe_account
    if self.merchant.nil?

      #create new merchant account
      require "stripe"
      Stripe.api_key = Rails.application.config.stripe_secret_key
      stripe = Stripe::Account.create(
        :type => 'custom',
        :country => 'US',
        :email => self.email,
        :payout_schedule => {
          :interval => "manual"
        }
       )

      merchant                    = Spree::Foodstem::Merchant.new
      merchant.user_id            = self.id
      merchant.stripe_account_id  = stripe.id
      merchant.destination        = "bank"
      merchant.first_name         = self.user_profile.first_name
      merchant.last_name          = self.user_profile.last_name
      merchant.date_of_birth      = "1926-12-13"
      merchant.email              = self.email
      merchant.account_number     = "123543"
      merchant.routing_number     = "011600033"
      merchant.save!
     return stripe.id
    else

      return self.merchant.stripe_account_id
    end
  end

end
