class ActiveSupport::TimeWithZone

  include ActionView::Helpers::DateHelper

  def my_strftime
    strftime('%Y-%m-%d %H:%M:%S.%N %Z')
  end

  def my_display
    #to_formatted_s(:short)
    time_ago_in_words(self)
  end

end
