class Spree::Foodstem::UserMailer < Spree::UserMailer

 alias_method :reset_password_instructions_old, :reset_password_instructions

  def confirmation_instructions(user, token, opts={})
    @confirmation_url = spree.spree_user_confirmation_url(confirmation_token: token)
    opts = opts.merge({
      to: user.email,
      from: from_address,
      subject: Spree::Store.current.name #+ ' ' + I18n.t(:subject, :scope => [:devise, :mailer, :confirmation_instructions]) #causing errors, have to revisit it
    })
    mail opts
  end

 def reset_password_instructions(record, token, opts={})

    @token = token
    @user = record
    opts = opts.merge({
      to: record.email,
      from: "Foodstems <no-reply@foodstems.com>",
      subject: "Foodstems Reset password instructions"
    })
     mail opts
    #reset_password_instructions_old(record, token, opts)
 end

  #send email to the seller when new order is placed
  def order_completed(order, opts={})
  	@order = order
    @url = "https://dev.foodstem.com/app"
  	opts = opts.merge({
  		#to: user.email,
  		to: order.vendor.email,
  		from: "Foodstems <no-reply@foodstems.com>",
  		subject: "You have new incoming order"
  	})

  	mail opts
  end

  #send email to the seller when new order is placed
  def payment_completed(order, opts={})
    @order = order
    @url = "https://dev.foodstem.com/app"
    opts = opts.merge({
      #to: user.email,
      to: order.vendor.email,
      from: "Foodstems <no-reply@foodstems.com>",
      subject: "Payment finished for order - #{@order.number}"
    })

    mail opts
  end  
end
