module Spree
  module Helpers
    module MyErrorHelper

      def merge_errors!(errors1, errors2)

      end

      def my_error_notification(obj, css_class = '')
        return '' if obj.errors.empty?
        ret = []
        ret << "<div class=\"alert alert-danger #{css_class}\">"
        ret << '<ul>'
        ret.push *obj.errors.full_messages.map { |e| "<li>#{e}</li>" }
        ret << '</ul>'
        ret << '</div>'
        ret.join("\n").html_safe
      end

      def my_error_to_flash(key, e, obj)
        flash[key] = {} unless flash[key]
        flash[key][:error] = obj && obj.errors.any? ? obj.errors.full_messages.join(' ') : e.message
      end

      def my_render_json_error(e, obj = nil, options = {})
        if obj && obj.errors.any?
          render json: { message: obj.errors.full_messages.join("\n") , messages: obj.errors.full_messages, errors: obj.errors }.merge(options), status: 500
        elsif e.nil?
          render json: { message: 'Unknown error', messages: [ 'Unknown error' ] }.merge(options), status: 500
        elsif e.is_a?(String)
          render json: { message: e, messages: [ e ] }.merge(options), status: 500
        else
          render json: { message: e.message, messages: [ e.message ] }.merge(options), status: 500
        end
      end

      def my_error_message(e, obj)
        if obj.nil? || obj.errors.empty?
          e.message
        else
          obj.errors.full_messages.join(' ')
        end
      end

      def my_alert_class_by_flash_key(flash_key)
        case flash_key
        when 'success'
          postfix = 'success'
        when 'warning'
          postfix = 'warning'
        when 'error'
          postfix = 'danger'
        else
          postfix = 'info'
        end
        "alert-#{postfix}"
      end

    end
  end

end
