module Spree
  module Helpers
    module NotifyHelper

      # Create notifications for user(s).
      # For convenience oneself notified only if flag notify_oneself is true.
      def self.my_notify(user, source, notify_oneself = false, options = {})
        if user.respond_to?(:each)
          user.each { |u| Spree::Foodstem::Notification.create({user: u, source: source}.merge(options)) if notify_oneself || u.id != spree_current_user.id }
        else
          Spree::Foodstem::Notification.create({user: user, source: source}.merge(options)) if notify_oneself || user.id != spree_current_user.id
        end
      end

      # Create notifications for user(s).
      # For convenience oneself notified only if flag notify_oneself is true.
      def my_notify(user, source, notify_oneself = false, options = {})
        if user.respond_to?(:each)
          user.each { |u| Spree::Foodstem::Notification.create({user: u, source: source}.merge(options)) if notify_oneself || u.id != spree_current_user.id }
        else
          Spree::Foodstem::Notification.create({user: user, source: source}.merge(options)) if notify_oneself || user.id != spree_current_user.id
        end
      end

      def self.notify_class(notification, options = {})
        clazz = "notif-#{notification.to_s.sub('_', '-')}"
        options.each do |opt, val|
          clazz << "_#{opt}-#{val}"
        end
        clazz
      end

      def my_notify_count(notification, options = {})
        spree_current_user.send("#{notification}_notifications").where(options).size
      end

      def my_notify_class(notification, options = {})
        Spree::Helpers::NotifyHelper.notify_class notification, options
      end

      def my_notify_badge(notification, options = {})
        my_notify_custom_badge notification, 'badge', options
      end

      def my_notify_custom_badge(notification, badge_class, options = {})
        count = my_notify_count(notification, options)
        hidden = count > 0 ? '' : ' style="display: none"'
        "<span class=\"#{badge_class} #{my_notify_class(notification, options)}\"#{hidden}>#{count}</span>"
      end
    end
  end
end
