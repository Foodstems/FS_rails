module Spree
  module Helpers
    module LinkToCol
      def mapping
        Rails.configuration.mapping
      end

      def link_to_col(body, path, html_options = {})
        unless html_options[:data]
          html_options[:data] = {}
        end
        unless !html_options[:data][:target_column].nil?
          html_options[:data][:target_column] = mapping[path]
        end
        html_options[:remote] = true
        real_path, method = process_path(path)

        if html_options[:url_helper_opts]
          url = self.send(real_path, html_options[:url_helper_opts])
          html_options.delete :url_helper_opts
        else
          url = self.send(real_path)
        end

        html_options[:method] = method if method
        link_to body, url, html_options
      end

      def col_num(path)
        mapping[path]
      end

      def form_for_col(obj, opts={}, &block)
        process_form_opts opts
        form_for obj, opts, &block
      end

      def form_tag_col(path, opts, &block)
        path = process_form_tag_opts path, opts
        form_tag path, opts, &block
      end

      def bootstrap_form_for_col(obj, opts={}, &block)
        process_form_opts opts
        bootstrap_form_for obj, opts, &block
      end

      def bootstrap_form_tag_col(opts={}, &block)
        
         opts
        bootstrap_form_tag opts, &block
      end

      def self.add_paths(map)
        if Rails.configuration.mapping
          Rails.configuration.mapping.merge! map
        else
          Rails.configuration.mapping = map
        end

      end

      def paginate_to_col(obj, column, params={})
        #:params => { :controller => 'comments', :action => 'index'
        paginate obj, params: params, remote: true, data: { 'target-column' => column }
      end

      private

      def process_form_tag_opts(path, opts)
        opts[:url] = path
        process_form_opts opts
        path = opts[:url]
        opts.delete :url
        return path
      end

      def process_form_opts(opts)

        opts[:remote] = true
        path, method = process_path(opts[:url])
        opts[:method] = method unless method.nil?
        if path
          unless opts[:data]
            opts[:data] = {}
          end
          unless !opts[:data][:target_column].nil?
            opts[:data][:target_column] = mapping[opts[:url]]
          end
          
          if opts[:url_helper_opts]
            opts[:url] = self.send(path, opts[:url_helper_opts])
            opts.delete :url_helper_opts
          else
            opts[:url] = self.send(path)
          end
        end
        return opts
      end

      def process_path(path)
        m = path.to_s.match(/^(GET|DELETE|POST|PATCH)(\d?[^_]*)_(.*)/)
        return path, nil if m.nil?
        real_path = m[3].to_sym
        method = m[1].downcase.to_sym
        return real_path, method
        #method = %w(GET DELETE POST PATCH).find do |method|
        #  path.to_s.start_with?(method + '_')
        #end
        #return path, nil if method.nil?
        #return path.to_s[(method + '_').length.. -1].to_sym, method.downcase.to_sym
      end

    end
  end
end
