module Spree
  module Helpers
    module ProductHelper

		def reduce_price(base_price, ptc) 
			return ptc.to_f * base_price.to_f 
		end
	end
  end 
end
