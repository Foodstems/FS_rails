module Spree::UserProfileHelper
  def avatar_tag(profile)
    link = if profile.nil? || profile.avatar.nil?
      'noimage/avatar.png'
    else
      profile.avatar.attachment.url(:product)
    end
    image_tag link, class: 'avatar img-circle'
  end
end
