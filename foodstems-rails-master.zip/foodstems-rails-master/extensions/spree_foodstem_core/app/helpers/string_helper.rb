module Spree
  module Helpers
    module StringHelper

      def reduce_price(base_price, ptc) 
        return (ptc.to_f/100) * base_price.to_f 
      end 
      # Split long words by invisible spaces
      def my_ww(str, options = {})
        unless options.is_a?(Hash)
          options = { length: options.to_i }
        end
        opts = { length: 10000, word_length: 10, shy_length: 4 }.merge(options)
        ret = ''
        offset = 0
        str = truncate(str, length: opts[:length]) if str.length > opts[:length]
        m = str.match(/[^\s\n\r]{#{opts[:word_length]},}/, offset)
        while m
          ret << h(str[offset..m.begin(0)-1]) if offset < m.begin(0)
          s = m[0].scan(/[^\s\n\r]{1,#{opts[:shy_length]}}/)
          ret << s.map{ |x| h(x) }.join('<wbr>')
          offset = m.end(0)
          m = str.match(/[^\s\n\r]{10,}/, offset)
        end
        ret << str[offset..-1]
        ret.html_safe
      end

      def my_s(str, length = 30)
        truncate(str, length: length)
      end

      def my_text(str)
        simple_format(h(str))
      end

      def my_wt(str)
        simple_format(my_ww(str))
      end




    end
  end
end
