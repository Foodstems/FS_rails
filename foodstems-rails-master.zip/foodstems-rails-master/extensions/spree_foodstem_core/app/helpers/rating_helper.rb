module Spree
  module Helpers
    module RatingHelper
      def my_rating_tag rating
        ret = '<div class="my-rating">'
        rating.times { ret += '<i class="fa fa-star fa-2x"></i>' }
        (5-rating).times { ret += '<i class="fa fa-star fa-2x my-rating-o"></i>' }
        ret += '</div>'
        raw(ret)
      end

      def feedback_tag rating
        unless rating
          return 'Not rated yet'
        end

        feedback_class =
            if rating >= 4.5
              'excellent-rating'
            elsif rating >= 4
              'good-rating'
            elsif rating >= 3
              'normal-rating'
            else
              'bad-rating'
            end

        rating_html = content_tag(:span, rating.round(2), class: "feedback-rating #{feedback_class}")
        raw "#{rating_html}"
      end
    end
  end
end
