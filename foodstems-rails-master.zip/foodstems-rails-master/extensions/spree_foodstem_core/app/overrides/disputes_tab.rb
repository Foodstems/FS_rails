Deface::Override.new(:virtual_path => "spree/admin/shared/_menu",
    :name => "disputes_admin_tab",
    :insert_bottom => "[data-hook='admin_tabs']",
    :text => "<%= tab :disputes,  :url => 'disputes', :icon => 'fa fa-dollar' %>",
    :disabled => false)