// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
(function () {
  'use strict';
  /**
   * Shortcut for jQuery document.on
   * @param evt event name
   * @param selector selector expression
   * @param cb callback
   */
  function live(evt, selector, cb) {
    return $(document).on(evt, selector, cb);
  }
  // Change display units in all fields
  //live('change', '#product_display_units', function () {
  //  $('#product_min_lot, #product_lot_quantifier').next().text($(this).val());
 //});

}) ();
