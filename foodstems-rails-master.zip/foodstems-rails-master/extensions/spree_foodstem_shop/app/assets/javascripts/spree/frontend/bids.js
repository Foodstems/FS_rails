Foodstem.Bids = {}
Foodstem.Bids.subscribe = function() {
	source = new EventSource('/bids/last_bid_event')
	source.addEventListener('message', function(e) {
		var data = JSON.parse(e.data)
	    if ("empty" in data) {
	        return false
	    } 
	    var bid 	= data[0].bid
	    var auction = data[0].auction
	    var product = data[0].product
	    var bids_no = data[0].bids_no
	    
	    if (Foodstem.Bids.getCurrentProductId() == product.id) {
	    	Foodstem.Bids.setNumberOfBids(bids_no)
    		Foodstem.Bids.setLastBid(bid.bid)
    		Foodstem.Bids.displayNotification();
		}
	})
}
Foodstem.Bids.init = function() {
	Foodstem.Bids.subscribe()
}

Foodstem.Bids.displayNotification = function() {
	$("#last_bid_updated_message").show().fadeOut(5000)
	$(document).find("#last_bid_updated_message_modal").show().fadeOut(5000)
}
Foodstem.Bids.getCurrentProductId = function() {
	return $("#product_id").val()
}
Foodstem.Bids.setNumberOfBids = function(bids_no) {
	if (bids_no==1) {
		Foodstem.Bids.setFirstBid(1)
	} else {
		$("#number_of_bids").html(bids_no)	
		$(document).find("#number_of_bids_modal").html(bids_no)
	}
	
}
Foodstem.Bids.setLastBid = function(last_bid) {
	$("#last_bid").html("$" + parseFloat(last_bid).toFixed(2))
	// update the modal if its open
	$(document).find("#last_bid_modal").html("$" + parseFloat(last_bid).toFixed(2))	
}

Foodstem.Bids.setFirstBid = function() {
	$("#first_bid_div").show()
}