// Placeholder manifest file.
// the installer will append this file to the app vendored assets here: vendor/assets/javascripts/spree/frontend/all.js'
//= require 'spree/frontend/products'
//= require 'spree/frontend/images'
//= require 'spree/frontend/markerclusterer'

Foodstem.Orders = {}
//Foodstem.Orders.role

Foodstem.Feedbacks = {}
//Foodstem.Feedbacks.orderNumber
//Foodstem.Feedbacks.userRole - opened page user role - 1 or 2. For feedback pages only

Foodstem.onOrders = function() {
  Foodstem.Feedbacks.initializeLeaveFeedbackModal(function(json) {
    var $x = $('#orders_table').find('tr[data-order-number=' + json.orderNumber
        + '][data-user-role=' + json.userRole + '] button');
    $x.remove();
  });
};

// triggered after incoming_orders.html.haml page loaded
Foodstem.onIncomingOrders = function() {
  Foodstem.onOrders();
  Foodstem.Orders.role = 1;
};

// triggered after outgoing_orders.html.haml page loaded
Foodstem.onOutgoingOrders = function() {
  Foodstem.onOrders();
  Foodstem.Orders.role = 2;
};

// triggered then feedbacks/index.html.haml page loaded
Foodstem.onFeedbacks = function() {
  Foodstem.Feedbacks.initializeLeaveFeedbackModal(function(json) {
    var $tr = $('#feedbacks_table').find('tr[data-order-number=' + json.orderNumber
        + '][data-user-role=' + json.userRole + ']');
    $tr.remove();
  });
};

Foodstem.Orders.onChangeStateButtonClicked = function(button) {
  $(button).bootstrapBtn('loading');
  var $tr = $(button).closest('tr');
  $tr.find('button').prop('disabled', true);
  var orderState = $(button).data('order-state');
  var orderNumber = $tr.data('order-number');
  $.ajax({
    url: '/orders/' + orderNumber + '/state',
    data: {
      _method: 'patch',
      state: {
        state: orderState,
        role: Foodstem.Orders.role
      }
    },
    type: 'post'
  }).done(function(html) {
      $tr.replaceWith(html);
  });
};

Foodstem.Feedbacks.onLeaveFeedbackButtonClicked = function(button) {
  $('#feedbacks_leave_feedback_rating').rating('update', 5);
  $('#feedbacks_leave_feedback_text').val('');
  $('#feedbacks_leave_feedback_text').focus();
  Foodstem.Feedbacks.orderNumber = $(button).data('order-number')
  Foodstem.Feedbacks.userRole = $(button).data('user-role')

};

Foodstem.Feedbacks.onLeaveUserFeedbackButtonClicked = function(button) {

  $('#user_feedbacks_leave_feedback_rating').val(5);
  $('#user_feedbacks_leave_feedback_text').val('');
  $('#user_feedbacks_leave_feedback_text').focus();
  Foodstem.Feedbacks.userRole = $(button).data('user-role')
  Foodstem.Feedbacks.reviewableUserId = $(button).data('reviewable-user')

};

// initialize modal dialog _leave_feedback.html.haml for leaving feedbacks
Foodstem.Feedbacks.initializeLeaveFeedbackModal = function(afterCallback) {

  $('#feedbacks_leave_feedback_rating').on('rating.change', function() {
      $('#feedbacks_leave_feedback_text').focus();
  });
  $('#feedbacks_leave_feedback_modal').on('shown.bs.modal', function () {
    $('#feedbacks_leave_feedback_text').focus();
  })

};

$('#feedbacks_leave_feedback_button').on('click', function() {
  /*
  Foodstem.Feedbacks.leaveFeedback($('#feedbacks_leave_feedback_rating').val(),
  $('#feedbacks_leave_feedback_text').val(), function(json) {
    $('#feedbacks_leave_feedback_modal').modal('hide');
    afterCallback(json);
  });
*/
});

// Leave a feedback for current order
Foodstem.Feedbacks.leaveFeedback = function(rating, text, doneCallback) {
  $.ajax({
    url: '/feedbacks/' + Foodstem.Feedbacks.orderNumber + '?format=json',
    type: 'POST',
    data: {
      _method: 'patch',
      feedback: {
        user_role: Foodstem.Feedbacks.userRole,
        rating: rating,
        text: text
      }
    }
  }).done(doneCallback).fail(function(jqXHR, textStatus, errorThrown) {
    swal(errorThrown, jqXHR.responseJSON.messages[0], 'error')
  });
};

Foodstem.Feedbacks.leaveUserFeedback = function(rating, text, doneCallback) {

  $.ajax({
    url: '/user_feedbacks/',
    type: 'POST',
    data: {
      feedback: {
        user_role: Foodstem.Feedbacks.userRole,
        rating: rating,
        text: text,
        reviewable_user_id: Foodstem.Feedbacks.reviewableUserId
      }
    }
  }).done(doneCallback).fail(function(jqXHR, textStatus, errorThrown) {
    swal(errorThrown, jqXHR.responseJSON.message, 'error')
  });
};