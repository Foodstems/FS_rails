
var PaymentMethods = function(){}
PaymentMethods.validate_form = function() {
	$('.help-inline').remove()
	$('.has-error').removeClass('has-error')
	var valid = true;
		var fields = [
			{"field":"card-number", "error_message":"Credit card number is required"},
			{"field":"cardholder_name", "error_message":"Cardholder name is required"},
			{"field":"cvv", "error_message":"CVV number is required"},
		]

		fields.forEach(function(elem){
			if ($("#"+elem.field).val() == "") {
				valid = false;
				$("#"+elem.field).parent("div").addClass("has-error")
				$("#"+elem.field).after('<span class="help-inline">'+elem.error_message+'</span>')
			}
		}) 
		return valid;
}
PaymentMethods.create_token = function() {
	Stripe.setPublishableKey($("#stripe_publish_key").val());
	Stripe.card.createToken({
	    number: 	$('#card-number').val(),
	    cvc: 		$('#cvv').val(),
		exp_month: 	$("#expiration_month").val(),
	    exp_year: 	$("#expiration_year").val(),
	    name: 		$('#cardholder_name').val() 
	}, stripeResponseHandler);
}

function stripeResponseHandler (status, response) {
	$(".stripe-error").remove()    

	if (response.error) {
	    $(".stripe-errors").append("<li class='stripe-error'>" + response.error.message + "</li>")
	} else {
	    var form$ = $("#add_payment_method_form");
        // token contains id, last4, and card type
        var token = response['id'];
        // insert the token into the form so it gets submitted to the server
        form$.append("<input type='hidden' id='stripeToken' name='stripeToken' value='" + token + "' />");
        $("#add_payment_method_form").submit()
	 }

}
$(function() {
	
	$(document).on("click", "#add_credit_card", function(e) {
		e.preventDefault()
		if (PaymentMethods.validate_form()) {
			PaymentMethods.create_token();	
		}	
	})

})