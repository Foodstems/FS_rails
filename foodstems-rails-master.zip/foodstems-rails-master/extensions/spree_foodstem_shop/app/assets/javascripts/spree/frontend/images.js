Foodstem.Images = {};

Foodstem.Images.deleteImage = function(elem, url, onComplete){
  var currentItem = elem;
  if(url){
    $.ajax({
      url: url,
      type: 'DELETE',
      success: onComplete? onComplete: function(){
        $(currentItem).remove();
      }
    });
  } else {
    currentItem.parent().append("<input name='product[deleted_images][]' type='hidden' value='"+currentItem[0].id+"' >");
    currentItem.remove();
  }
};

Foodstem.Images.loadImagePicker = function(imageShow, imagePicker, navigation, lazyLoad){
  imageShow.owlCarousel({
    singleItem : true,
    navigation: navigation,
    navigationText: [
      "<i class='fa fa-chevron-left'></i>",
      "<i class='fa fa-chevron-right'></i>"
    ],
    lazyLoad: lazyLoad,
    slideSpeed : 500,
    pagination: false,
    afterAction : syncPosition,
    responsiveRefreshRate : 100,
  });

  imagePicker.owlCarousel({
    items : 6,
    itemsDesktop      : [1199,5],
    itemsDesktopSmall     : [979,5],
    itemsTablet       : [768,5],
    itemsMobile       : [479,4],
    lazyLoad: lazyLoad,
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
      el.find(".owl-item").eq(0).addClass("current");
    }
  });

  function syncPosition(el){
    var current = this.currentItem;
    imagePicker
      .find(".owl-item")
      .removeClass("current")
      .eq(current)
      .addClass("current")
    if(imagePicker.data("owlCarousel") !== undefined){
      center(current)
    }
  }

  imagePicker.on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    imageShow.trigger("owl.goTo",number);
  });

  function center(number){
    var imagePickervisible = imagePicker.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in imagePickervisible){
      if(num === imagePickervisible[i]){
        var found = true;
      }
    }

    if(found===false){
      if(num>imagePickervisible[imagePickervisible.length-1]){
        imagePicker.trigger("owl.goTo", num - imagePickervisible.length+2)
      }else{
        if(num - 1 === -1){
          num = 0;
        }
        imagePicker.trigger("owl.goTo", num);
      }
    } else if(num === imagePickervisible[imagePickervisible.length-1]){
      imagePicker.trigger("owl.goTo", imagePickervisible[1])
    } else if(num === imagePickervisible[0]){
      imagePicker.trigger("owl.goTo", num-1)
    }

  }
}