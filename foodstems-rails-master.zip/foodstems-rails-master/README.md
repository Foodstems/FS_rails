# INSTALL #

* rake db:setup RAILS_ENV=production
* rake assets:precompile RAILS_ENV=production
* rails s -e production